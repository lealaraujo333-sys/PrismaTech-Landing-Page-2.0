# Prisma - AI-Powered Customer Service Platform

A modern, responsive landing page built with Next.js 14, TypeScript, Tailwind CSS, and Framer Motion.

## Features

- 🎨 Modern design with gradient backgrounds and glassmorphism effects
- ⚡ Built with Next.js 14 and React 18
- 🎭 Smooth animations using Framer Motion
- 📱 Fully responsive design
- 🎯 TypeScript for type safety
- 💨 Tailwind CSS for styling
- 🌈 Custom color palette matching the original design

## Getting Started

### Prerequisites

- Node.js 18+ installed on your machine
- npm, yarn, or pnpm package manager

### Installation

1. Install dependencies:

```bash
npm install
# or
yarn install
# or
pnpm install
```

2. Run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
```

3. Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## Project Structure

```
prisma-landing/
├── app/
│   ├── layout.tsx          # Root layout with fonts
│   ├── page.tsx            # Main page
│   └── globals.css         # Global styles
├── components/
│   ├── Navigation.tsx      # Header navigation
│   ├── Hero.tsx           # Hero section
│   ├── Features.tsx       # Features grid
│   ├── Demo.tsx           # Interactive demo
│   ├── Benefits.tsx       # Benefits & stats
│   ├── CTA.tsx            # Call-to-action
│   └── Footer.tsx         # Footer
├── public/                # Static assets
├── tailwind.config.ts     # Tailwind configuration
├── tsconfig.json          # TypeScript configuration
└── package.json           # Dependencies
```

## Customization

### Colors

Edit the color scheme in `tailwind.config.ts`:

```typescript
colors: {
  dark: {
    DEFAULT: '#010101',
    light: '#0a090d',
  },
  purple: {
    DEFAULT: '#8759f2',
    light: '#9d7ff5',
  },
}
```

### Fonts

The project uses Space Grotesk from Google Fonts configured in `app/layout.tsx`:
- Space Grotesk (all text - headings and body)
- Weights: 300, 400, 500, 600, 700

### Content

Edit the content in each component file:
- Navigation links in `components/Navigation.tsx`
- Hero text in `components/Hero.tsx`
- Features in `components/Features.tsx`
- Demo conversations in `components/Demo.tsx`
- Benefits and stats in `components/Benefits.tsx`
- Partners logos in `components/Partners.tsx`

### WhatsApp Links

All WhatsApp links use the placeholder number `5511999999999`. Update this in:
- `components/Navigation.tsx`
- `components/Hero.tsx`
- `components/CTA.tsx`

Replace with your actual WhatsApp number in international format (country code + number).

### Partner Logos

To add partner logos:
1. Create a folder `/public/partners/`
2. Add partner logo images (PNG/SVG format recommended)
3. Update the `partners` array in `components/Partners.tsx` with actual image paths
4. Replace placeholder content with real partner information

## Build for Production

```bash
npm run build
npm start
```

## Technologies Used

- **Next.js 14** - React framework
- **TypeScript** - Type safety
- **Tailwind CSS** - Utility-first CSS
- **Framer Motion** - Animation library
- **Google Fonts** - Typography

## License

This project is created for Prisma and is proprietary.
