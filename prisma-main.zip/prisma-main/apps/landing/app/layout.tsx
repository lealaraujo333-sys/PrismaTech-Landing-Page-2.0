import type { Metadata } from 'next'
import { Space_Grotesk } from 'next/font/google'
import './globals.css'
import AppLoader from '@/components/AppLoader'

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-space-grotesk',
  display: 'swap',
  weight: ['300', '400', '500', '600', '700'],
})

export const metadata: Metadata = {
  title: 'Prisma - Agência Digital de Marketing e Tecnologia',
  description: 'Ajudamos empresas a crescerem com previsibilidade, lucratividade e posicionamento sólido no mercado através de marketing, automação e IA',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR" className={spaceGrotesk.variable}>
      <head>
        {/* Preload critical assets for instant loader */}
        <link rel="preload" href="/logo_white.png" as="image" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
      </head>
      <body>
        <AppLoader>{children}</AppLoader>
      </body>
    </html>
  )
}
