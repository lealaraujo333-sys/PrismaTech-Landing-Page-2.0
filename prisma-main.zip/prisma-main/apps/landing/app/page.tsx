import dynamic from 'next/dynamic'

// Critical components - Load immediately (above the fold)
import Navigation from '@/components/Navigation'
import Hero from '@/components/Hero'

// Non-critical components - Load dynamically (lazy load)
const Manifesto = dynamic(() => import('@/components/Manifesto'), {
  loading: () => null, // No loading spinner to avoid layout shift
})

const Features = dynamic(() => import('@/components/Features'), {
  loading: () => null,
})

const Demo = dynamic(() => import('@/components/Demo'), {
  loading: () => null,
})

const Benefits = dynamic(() => import('@/components/Benefits'), {
  loading: () => null,
})

const Partners = dynamic(() => import('@/components/Partners'), {
  loading: () => null,
})

const CTA = dynamic(() => import('@/components/CTA'), {
  loading: () => null,
})

const Footer = dynamic(() => import('@/components/Footer'), {
  loading: () => null,
})

export default function Home() {
  return (
    <main className="min-h-screen bg-dark">
      {/* Critical - Loads immediately */}
      <Navigation />
      <Hero />

      {/* Below the fold - Lazy loaded */}
      <Manifesto />
      <Features />
      <Demo />
      <Benefits />
      <Partners />
      <CTA />
      <Footer />
    </main>
  )
}
