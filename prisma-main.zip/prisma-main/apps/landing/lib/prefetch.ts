/**
 * Prefetch Strategy
 * Carrega os componentes pesados logo após o loader terminar
 * Isso garante que quando o usuário scrollar, já estão prontos
 */

export function prefetchComponents() {
  if (typeof window === 'undefined') return

  // Aguarda idle callback para não bloquear thread principal
  if ('requestIdleCallback' in window) {
    requestIdleCallback(
      () => {
        // Prefetch dinâmico dos componentes
        import('@/components/Manifesto')
        import('@/components/Features')
        import('@/components/Demo')
      },
      { timeout: 2000 }
    )

    // Segunda onda de prefetch (componentes menos críticos)
    requestIdleCallback(
      () => {
        import('@/components/Benefits')
        import('@/components/Partners')
        import('@/components/CTA')
        import('@/components/Footer')
      },
      { timeout: 3000 }
    )
  } else {
    // Fallback para navegadores sem requestIdleCallback
    setTimeout(() => {
      import('@/components/Manifesto')
      import('@/components/Features')
      import('@/components/Demo')
      import('@/components/Benefits')
      import('@/components/Partners')
      import('@/components/CTA')
      import('@/components/Footer')
    }, 1000)
  }
}
