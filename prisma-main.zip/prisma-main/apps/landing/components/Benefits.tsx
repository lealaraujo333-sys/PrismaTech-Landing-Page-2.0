'use client'

import { motion } from 'framer-motion'

const benefits = [
  {
    stat: '3x',
    label: 'ROI em 12 meses',
  },
  {
    stat: '70%',
    label: 'Redução de custos',
  },
  {
    stat: '24/7',
    label: 'IA trabalhando',
  },
  {
    stat: '100%',
    label: 'Foco em lucro',
  },
]

export default function Benefits() {
  return (
    <section id="resultados" className="py-32 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          viewport={{ once: true, margin: "-100px" }}
          className="text-center mb-20"
        >
          <motion.h2
            className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 px-4 leading-tight"
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            viewport={{ once: true }}
          >
            Resultado real, não <span className="gradient-text-animated">promessas vazias</span>
          </motion.h2>
          <p className="text-base sm:text-lg md:text-xl text-white/80 max-w-3xl mx-auto px-4 leading-relaxed">
            Medimos sucesso por <strong className="text-white">lucro no caixa</strong>, não por curtidas
          </p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8 mb-16 md:mb-20 px-4">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8, y: 30 }}
              whileInView={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.12, ease: [0.22, 1, 0.36, 1] }}
              viewport={{ once: true, margin: "-50px" }}
              className="text-center"
            >
              <div className="text-4xl sm:text-5xl md:text-6xl font-bold gradient-text mb-3 md:mb-4">
                {benefit.stat}
              </div>
              <div className="text-white/75 text-base md:text-lg leading-snug">{benefit.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Problem-Solution */}
        <div className="grid md:grid-cols-1 gap-8 mb-16 px-4">
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            viewport={{ once: true, margin: "-100px" }}
            className="bg-gradient-to-br from-red-500/10 to-red-600/10 backdrop-blur-sm rounded-3xl p-8 md:p-12 border border-red-500/20"
          >
            <h3 className="text-2xl md:text-3xl font-bold mb-5 md:mb-6 text-red-400 leading-tight">O Problema que Resolvemos</h3>
            <p className="text-base md:text-lg lg:text-xl text-white/85 mb-6 leading-relaxed">
              Crescer exige investimento de tempo e dinheiro. Mas sem estratégia e posicionamento claro, você só desperdiça recursos e acumula dor de cabeça. <strong className="text-white">Com a Prisma, você terceiriza execução complexa e aumenta faturamento reduzindo custos.</strong>
            </p>
            <ul className="space-y-3 md:space-y-4">
              <li className="flex items-start">
                <svg className="w-5 h-5 md:w-6 md:h-6 text-red-400 mr-2 md:mr-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
                <span className="text-sm md:text-base text-white/85 leading-snug">Captação imprevisível gerando sazonalidade no faturamento</span>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 md:w-6 md:h-6 text-red-400 mr-2 md:mr-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
                <span className="text-sm md:text-base text-white/85 leading-snug">Posicionamento fraco frente à concorrência</span>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 md:w-6 md:h-6 text-red-400 mr-2 md:mr-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
                <span className="text-sm md:text-base text-white/85 leading-snug">Tráfego pago queimando dinheiro sem retorno consistente</span>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 md:w-6 md:h-6 text-red-400 mr-2 md:mr-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
                <span className="text-sm md:text-base text-white/85 leading-snug">Processos que não escalam e dependência total de pessoas</span>
              </li>
            </ul>
          </motion.div>
        </div>

        {/* Benefits Cards */}
        <div className="grid md:grid-cols-2 gap-6 md:gap-8 px-4">
          <motion.div
            initial={{ opacity: 0, x: -60, scale: 0.95 }}
            whileInView={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            viewport={{ once: true, margin: "-100px" }}
            className="bg-gradient-to-br from-purple/10 to-purple-light/10 backdrop-blur-sm rounded-3xl p-8 md:p-12 border border-white/10"
          >
            <h3 className="text-2xl md:text-3xl font-bold mb-5 md:mb-6 leading-tight">O Que Você Ganha</h3>
            <ul className="space-y-3 md:space-y-4">
              <li className="flex items-start">
                <svg className="w-5 h-5 md:w-6 md:h-6 text-purple mr-2 md:mr-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="text-sm md:text-base text-white/85 leading-snug">Redução de até 70% nos custos operacionais</span>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 md:w-6 md:h-6 text-purple mr-2 md:mr-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="text-sm md:text-base text-white/85 leading-snug">Crescimento sem contratar mais pessoas</span>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 md:w-6 md:h-6 text-purple mr-2 md:mr-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="text-sm md:text-base text-white/85 leading-snug">Visibilidade total sobre ROI e métricas reais</span>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 md:w-6 md:h-6 text-purple mr-2 md:mr-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="text-sm md:text-base text-white/85 leading-snug">Posicionamento de autoridade no seu mercado</span>
              </li>
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 60, scale: 0.95 }}
            whileInView={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            viewport={{ once: true, margin: "-100px" }}
            className="bg-gradient-to-br from-purple/10 to-purple-light/10 backdrop-blur-sm rounded-3xl p-8 md:p-12 border border-white/10"
          >
            <h3 className="text-2xl md:text-3xl font-bold mb-5 md:mb-6 leading-tight">Por Que Somos Diferentes</h3>
            <ul className="space-y-3 md:space-y-4">
              <li className="flex items-start">
                <svg className="w-5 h-5 md:w-6 md:h-6 text-purple mr-2 md:mr-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="text-sm md:text-base text-white/85 leading-snug">Marketing + Automação + IA em um só lugar</span>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 md:w-6 md:h-6 text-purple mr-2 md:mr-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="text-sm md:text-base text-white/85 leading-snug">100% remoto, trabalhamos como sua equipe interna</span>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 md:w-6 md:h-6 text-purple mr-2 md:mr-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="text-sm md:text-base text-white/85 leading-snug">Tecnologia proprietária + inteligência de negócio</span>
              </li>
              <li className="flex items-start">
                <svg className="w-5 h-5 md:w-6 md:h-6 text-purple mr-2 md:mr-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                <span className="text-sm md:text-base text-white/85 leading-snug">Especializados em empresas de R$ 600k a R$ 4M/ano</span>
              </li>
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
