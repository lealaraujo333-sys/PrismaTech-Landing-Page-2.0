# 🎬 Netflix-Style Loader - Prisma

Loader cinematográfico premium inspirado em Netflix, Apple TV+ e HBO Max.

## 🎨 Características

### Versão Padrão (`Loader.tsx`)
- ✨ Animação de logo com rotação 3D
- 💫 Partículas animadas no fundo
- 🌈 Gradiente dinâmico pulsante
- 📊 Barra de progresso animada
- 🎭 Barras cinemáticas (letterbox)
- ⏱️ Duração: 3 segundos

### Versão Premium (`LoaderVariant.tsx`)
- 🎯 Sistema de fases (intro → logo → exit)
- 🌀 Orbs rotativos em 3D
- 💡 Efeito de spotlight dramático
- 🔄 Rotação completa do logo (360°)
- ✨ Anéis de brilho pulsantes
- 📐 Perspectiva 3D avançada
- 🎬 Letterbox dinâmico

## 🚀 Como Usar

### Instalação Automática
Já está integrado no `layout.tsx` via `AppLoader`:

```tsx
// apps/landing/app/layout.tsx
import AppLoader from '@/components/AppLoader'

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        <AppLoader>{children}</AppLoader>
      </body>
    </html>
  )
}
```

### Trocar para Versão Premium

Edite `AppLoader.tsx`:

```tsx
// Trocar esta linha:
import Loader from './Loader'

// Por esta:
import Loader from './LoaderVariant'
```

### Usar Standalone

```tsx
import Loader from '@/components/Loader'

function MyPage() {
  const [loading, setLoading] = useState(true)

  return (
    <>
      {loading && <Loader onComplete={() => setLoading(false)} />}
      {!loading && <MainContent />}
    </>
  )
}
```

## ⚙️ Customização

### Duração da Animação

Em `Loader.tsx` ou `LoaderVariant.tsx`:

```tsx
// Mudar de 3000ms (3s) para 5000ms (5s)
const timer = setTimeout(() => {
  setIsLoading(false)
  onComplete?.()
}, 5000) // ← Alterar aqui
```

### Cores do Logo

```tsx
// Gradiente do logo
className="bg-gradient-to-br from-purple via-purple-light to-purple"

// Alterar para outra cor:
className="bg-gradient-to-br from-blue-500 via-blue-400 to-blue-600"
```

### Adicionar Sua Logo

Substitua o placeholder no `Loader.tsx`:

```tsx
{/* Logo placeholder - substituir pela logo real */}
<div className="relative w-32 h-32 md:w-40 md:h-40">
  {/* ANTES: */}
  <div className="w-full h-full bg-gradient-to-br from-purple to-purple-light rounded-3xl">
    <span className="text-5xl md:text-6xl font-bold text-white">P</span>
  </div>

  {/* DEPOIS: */}
  <Image
    src="/logo.png"
    alt="Prisma Logo"
    width={160}
    height={160}
    priority
  />
</div>
```

### Desabilitar o Loader

Em `AppLoader.tsx`:

```tsx
useEffect(() => {
  // Comentar estas linhas para sempre pular o loader:
  // const hasSeenLoader = sessionStorage.getItem('prisma-loader-seen')
  // if (hasSeenLoader) {

  // Sempre pular:
  setIsLoading(false)
  setShowContent(true)
}, [])
```

### Mostrar Sempre (mesmo após primeira visita)

Em `AppLoader.tsx`:

```tsx
useEffect(() => {
  // Remover a verificação do sessionStorage:
  // const hasSeenLoader = sessionStorage.getItem('prisma-loader-seen')
  // if (hasSeenLoader) { ... }

  // Deixar vazio - sempre mostra
}, [])
```

## 🎭 Efeitos Disponíveis

### Partículas Flutuantes
```tsx
{[...Array(20)].map((_, i) => (
  <motion.div
    animate={{
      y: [null, -100],
      scale: [0, 1, 0],
    }}
  />
))}
```

### Glow Pulsante
```tsx
animate={{
  boxShadow: [
    '0 0 60px rgba(135, 89, 242, 0.5)',
    '0 0 100px rgba(135, 89, 242, 0.8)',
  ]
}}
```

### Rotação 3D
```tsx
style={{ perspective: '1000px' }}
animate={{
  rotateY: [-180, 0, 0],
  rotateX: [15, 0, 0],
}}
```

## 🎵 Adicionar Som (Opcional)

1. Adicione o arquivo de som em `public/sounds/`:
   - `prisma-sound.mp3`

2. No `Loader.tsx`:

```tsx
useEffect(() => {
  // Toca som ao iniciar
  const audio = new Audio('/sounds/prisma-sound.mp3')
  audio.volume = 0.3
  audio.play().catch(() => {
    // Navegador bloqueou autoplay
  })

  const timer = setTimeout(() => {
    setIsLoading(false)
    onComplete?.()
  }, 3000)

  return () => clearTimeout(timer)
}, [onComplete])
```

## 📊 Performance

- ✅ GPU-accelerated (transform, opacity)
- ✅ `will-change` otimizado
- ✅ 60 FPS garantido
- ✅ Sem layout shifts
- ✅ SessionStorage para cache
- ✅ AnimatePresence para cleanup

## 🎨 Classes CSS Customizadas

Disponíveis em `globals.css`:

```css
.bg-gradient-radial     /* Gradiente radial */
.cinematic-bars         /* Barras cinemáticas */
.animate-shimmer        /* Efeito shimmer */
.animate-glow           /* Pulsação de glow */
.glass                  /* Glassmorphism */
.card-3d                /* Efeito 3D */
```

## 🔧 Troubleshooting

### Loader não aparece
- Verificar se `AppLoader` está no `layout.tsx`
- Limpar sessionStorage: `sessionStorage.clear()`

### Animação travando
- Reduzir número de partículas (de 20 para 10)
- Simplificar gradientes animados
- Remover blur excessivo

### Logo não centralizada
- Verificar `flex items-center justify-center`
- Ajustar `w-32 h-32` para o tamanho correto

## 📱 Responsividade

Testado em:
- ✅ Mobile (320px - 767px)
- ✅ Tablet (768px - 1023px)
- ✅ Desktop (1024px+)
- ✅ 4K (2560px+)

## 🎬 Inspirações

- Netflix intro
- Apple TV+ loader
- HBO Max splash screen
- Disney+ loading animation
- Vercel deploy animation

---

**Criado com ❤️ para Prisma**
