'use client'

import { useState, useEffect, Suspense } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import dynamic from 'next/dynamic'
import { prefetchComponents } from '@/lib/prefetch'

// 🎬 Escolha seu loader:
// import Loader from './Loader'           // ✨ Versão padrão (clean, rápida)
import Loader from './LoaderVariant'       // 🎭 Versão premium (cinematográfica)

interface AppLoaderProps {
  children: React.ReactNode
}

/**
 * Two-Phase Loading System
 * Phase 1: Loader runs ALONE (60 FPS guaranteed)
 * Phase 2: Content loads AFTER loader completes
 *
 * Comportamento:
 * - DEV: Sempre mostra loader (para testes)
 * - PROD: Mostra 1x por sessão (UX otimizada)
 *
 * Para forçar sempre mostrar: ALWAYS_SHOW_LOADER = true
 * Para nunca mostrar: ALWAYS_SHOW_LOADER = false, SKIP_LOADER = true
 */

// ⚙️ Configurações
const ALWAYS_SHOW_LOADER = false  // true = sempre mostra (mesmo em prod)
const SKIP_LOADER = false         // true = nunca mostra (dev rápido)

export default function AppLoader({ children }: AppLoaderProps) {
  const [loadingPhase, setLoadingPhase] = useState<'loader' | 'content' | 'ready'>('loader')
  const [renderContent, setRenderContent] = useState(false)

  useEffect(() => {
    const isDev = process.env.NODE_ENV === 'development'

    // Opção 1: Pular loader completamente (dev rápido)
    if (SKIP_LOADER) {
      setLoadingPhase('ready')
      setRenderContent(true)
      return
    }

    // Opção 2: Sempre mostrar loader (forçar em prod)
    if (ALWAYS_SHOW_LOADER) {
      return // Mostra o loader
    }

    // Opção 3: DEV sempre mostra, PROD mostra 1x por sessão
    if (isDev) {
      // DEV: Sempre mostra o loader
      return
    }

    // PRODUÇÃO: Verifica se já mostrou o loader antes
    const hasSeenLoader = sessionStorage.getItem('prisma-loader-seen')

    if (hasSeenLoader) {
      // Se já viu, pula direto para o conteúdo
      setLoadingPhase('ready')
      setRenderContent(true)
    } else {
      // Marca que já viu o loader
      sessionStorage.setItem('prisma-loader-seen', 'true')
    }
  }, [])

  const handleLoadComplete = () => {
    // Fase 1: Loader terminou
    setLoadingPhase('content')

    // Inicia prefetch dos componentes pesados
    prefetchComponents()

    // Aguarda animação de saída do loader
    setTimeout(() => {
      // Fase 2: Começa a renderizar o conteúdo
      setRenderContent(true)

      // Aguarda conteúdo montar no DOM
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          // Fase 3: Mostra o conteúdo com fade in
          setLoadingPhase('ready')
        })
      })
    }, 600) // Tempo da animação de exit do loader
  }

  return (
    <>
      {/* Phase 1: Loader ISOLADO - Sem outros componentes renderizando */}
      <AnimatePresence mode="wait">
        {loadingPhase === 'loader' && (
          <Loader onComplete={handleLoadComplete} />
        )}
      </AnimatePresence>

      {/* Phase 2: Conteúdo renderiza APENAS após loader sair */}
      {renderContent && (
        <AnimatePresence mode="wait">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{
              opacity: loadingPhase === 'ready' ? 1 : 0
            }}
            transition={{
              duration: 0.6,
              ease: [0.22, 1, 0.36, 1],
              delay: 0.1
            }}
            style={{
              willChange: loadingPhase === 'content' ? 'opacity' : 'auto'
            }}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      )}
    </>
  )
}
