'use client'

import { motion } from 'framer-motion'

const manifestoLines = [
  "O marketing tradicional morreu",
  "Chega de fórmulas prontas e promessas vazias que só geram despesas",
  "A Prisma é diferente. Somos o futuro.",
  "Não medimos sucesso por curtidas ou seguidores.",
  "Medimos por lucro real no seu caixa.",
  "Não tentamos impressionar algoritmos.",
  "Tentamos fazer empresas lucrarem enquanto crescem.",
  "E nisso, somos imbatíveis."
]

export default function Manifesto() {
  return (
    <section id="manifesto" className="py-32 px-6 relative overflow-hidden bg-gradient-to-b from-dark to-dark-light">
      {/* Background Effects */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.3, 0.1],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-purple/20 rounded-full blur-[200px]"
        />
      </div>

      <div className="max-w-5xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          viewport={{ once: true, margin: "-100px" }}
          className="text-center mb-16"
        >
          <motion.h2
            className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-8 px-4"
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            viewport={{ once: true }}
          >
            Nosso <span className="gradient-text-animated">Manifesto</span>
          </motion.h2>
        </motion.div>

        <div className="space-y-6 md:space-y-8 px-4">
          {manifestoLines.map((line, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -60 : 60 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{
                duration: 0.8,
                delay: index * 0.12,
                ease: [0.22, 1, 0.36, 1]
              }}
              viewport={{ once: true, margin: "-50px" }}
              className={`${
                index === manifestoLines.length - 1
                  ? 'text-center'
                  : index % 2 === 0
                    ? 'text-left'
                    : 'text-right'
              }`}
            >
              <p className={`${
                index === 0 || index === 2
                  ? 'text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight'
                  : index === manifestoLines.length - 1
                    ? 'text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold gradient-text-animated leading-tight'
                    : 'text-xl sm:text-2xl md:text-3xl lg:text-4xl font-medium text-white/85 leading-relaxed'
              }`}>
                {line}
              </p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.5, ease: [0.22, 1, 0.36, 1] }}
          viewport={{ once: true }}
          className="mt-20 text-center"
        >
          <motion.a
            href="https://wa.me/5511999999999?text=Olá,%20me%20identifiquei%20com%20o%20manifesto%20da%20Prisma"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.08, boxShadow: "0 20px 60px rgba(135, 89, 242, 0.5)" }}
            whileTap={{ scale: 0.95 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
            className="inline-block px-8 sm:px-10 py-4 sm:py-5 bg-purple rounded-full text-base sm:text-lg md:text-xl font-semibold hover:bg-purple-light transition-colors shadow-lg shadow-purple/50"
          >
            Quero Fazer Parte Disso
          </motion.a>
        </motion.div>
      </div>
    </section>
  )
}
