'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useState, useEffect } from 'react'
import Image from 'next/image'

interface LoaderProps {
  onComplete?: () => void
}

export default function Loader({ onComplete }: LoaderProps) {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Duração total da animação: 3 segundos
    const timer = setTimeout(() => {
      setIsLoading(false)
      onComplete?.()
    }, 3000)

    return () => clearTimeout(timer)
  }, [onComplete])

  return (
    <AnimatePresence mode="wait">
      {isLoading && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-dark overflow-hidden"
        >
          {/* Animated background gradient */}
          <motion.div
            className="absolute inset-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-br from-purple/20 via-dark to-purple-light/20"
              animate={{
                scale: [1, 1.2, 1],
                rotate: [0, 90, 0],
              }}
              transition={{
                duration: 3,
                ease: "easeInOut"
              }}
            />
          </motion.div>

          {/* Animated particles */}
          <div className="absolute inset-0 overflow-hidden">
            {[...Array(20)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-purple/30 rounded-full"
                initial={{
                  x: Math.random() * window.innerWidth,
                  y: Math.random() * window.innerHeight,
                  scale: 0,
                }}
                animate={{
                  y: [null, -100],
                  scale: [0, 1, 0],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 2,
                  delay: Math.random() * 2,
                  repeat: Infinity,
                  ease: "easeOut"
                }}
              />
            ))}
          </div>

          {/* Main logo container */}
          <div className="relative z-10">
            {/* Glow effect behind logo */}
            <motion.div
              className="absolute inset-0 blur-[100px]"
              initial={{ scale: 0, opacity: 0 }}
              animate={{
                scale: [0, 1.5, 1],
                opacity: [0, 0.6, 0],
              }}
              transition={{
                duration: 2.5,
                times: [0, 0.5, 1],
                ease: [0.22, 1, 0.36, 1]
              }}
            >
              <div className="w-full h-full bg-purple" />
            </motion.div>

            {/* Logo with animation */}
            <motion.div
              initial={{ scale: 0.5, opacity: 0, rotateY: -180 }}
              animate={{
                scale: [0.5, 1.2, 1],
                opacity: [0, 1, 1],
                rotateY: [-180, 0, 0],
              }}
              transition={{
                duration: 1.5,
                times: [0, 0.6, 1],
                ease: [0.22, 1, 0.36, 1]
              }}
              className="relative"
              style={{ perspective: '1000px' }}
            >
              {/* Prisma Logo - Clean */}
              <motion.div
                className="relative w-48 h-48 md:w-56 md:h-56"
                animate={{
                  filter: [
                    'drop-shadow(0 0 40px rgba(135, 89, 242, 0.6))',
                    'drop-shadow(0 0 60px rgba(135, 89, 242, 0.9))',
                    'drop-shadow(0 0 40px rgba(135, 89, 242, 0.6))',
                  ],
                  scale: [0.95, 1.05, 0.95],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <Image
                  src="/logo_white.png"
                  alt="Prisma"
                  fill
                  priority
                  quality={100}
                  className="object-contain"
                  style={{
                    filter: 'brightness(1.1) contrast(1.1)',
                  }}
                />
              </motion.div>
            </motion.div>

            {/* Brand name */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.8,
                delay: 1,
                ease: [0.22, 1, 0.36, 1]
              }}
              className="text-center mt-8"
            >
              <motion.h1
                className="text-4xl md:text-5xl font-bold gradient-text-animated"
                animate={{
                  opacity: [0.5, 1, 0.5],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                PRISMA
              </motion.h1>
            </motion.div>

            {/* Loading bar */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.5 }}
              className="mt-12 w-64 h-1 bg-white/10 rounded-full overflow-hidden"
            >
              <motion.div
                className="h-full bg-gradient-to-r from-purple via-purple-light to-purple rounded-full"
                initial={{ x: '-100%' }}
                animate={{ x: '100%' }}
                transition={{
                  duration: 1.5,
                  delay: 1.5,
                  ease: [0.22, 1, 0.36, 1]
                }}
              />
            </motion.div>
          </div>

          {/* Cinematic bars (like Netflix) */}
          <motion.div
            className="absolute top-0 left-0 right-0 h-20 bg-black"
            initial={{ y: -80 }}
            animate={{ y: 0 }}
            exit={{ y: -80 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          />
          <motion.div
            className="absolute bottom-0 left-0 right-0 h-20 bg-black"
            initial={{ y: 80 }}
            animate={{ y: 0 }}
            exit={{ y: 80 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          />

          {/* Vignette effect */}
          <div className="absolute inset-0 pointer-events-none">
            <div className="w-full h-full bg-gradient-radial from-transparent via-transparent to-black opacity-50" />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
