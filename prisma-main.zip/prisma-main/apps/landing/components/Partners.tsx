'use client'

import { motion } from 'framer-motion'

// Placeholder for partner logos - replace with actual partner images
const partners = [
  { name: 'Partner 1', logo: '/partners/partner1.png' },
  { name: 'Partner 2', logo: '/partners/partner2.png' },
  { name: 'Partner 3', logo: '/partners/partner3.png' },
  { name: 'Partner 4', logo: '/partners/partner4.png' },
  { name: 'Partner 5', logo: '/partners/partner5.png' },
  { name: 'Partner 6', logo: '/partners/partner6.png' },
]

export default function Partners() {
  return (
    <section className="py-20 px-6 relative border-t border-white/10">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          viewport={{ once: true, margin: "-100px" }}
          className="text-center mb-12"
        >
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 px-4 leading-tight">
            Empresas que <span className="gradient-text">confiam</span> na Prisma
          </h2>
          <p className="text-base sm:text-lg text-white/80 px-4">
            Clientes que já transformaram crescimento em lucro
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6 lg:gap-8 items-center px-4">
          {partners.map((partner, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8, y: 30 }}
              whileInView={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.08, ease: [0.22, 1, 0.36, 1] }}
              viewport={{ once: true, margin: "-50px" }}
              whileHover={{ scale: 1.05, y: -5 }}
              className="group"
            >
              <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 md:p-6 border border-white/10 hover:border-purple/50 transition-all flex items-center justify-center min-h-[100px] md:min-h-[120px]">
                {/* Placeholder - replace with actual images */}
                <div className="text-center">
                  <div className="w-12 h-12 md:w-16 md:h-16 mx-auto mb-2 bg-purple/20 rounded-lg flex items-center justify-center group-hover:bg-purple/30 transition-colors">
                    <svg className="w-6 h-6 md:w-8 md:h-8 text-purple" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                    </svg>
                  </div>
                  <p className="text-xs text-white/60">{partner.name}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
          className="text-center mt-10 md:mt-12 px-4"
        >
          <p className="text-sm md:text-base text-white/70">
            Sua empresa pode ser a próxima. <a href="#planos" className="text-purple hover:text-purple-light transition-colors font-semibold">Fale conosco</a>
          </p>
        </motion.div>
      </div>
    </section>
  )
}
