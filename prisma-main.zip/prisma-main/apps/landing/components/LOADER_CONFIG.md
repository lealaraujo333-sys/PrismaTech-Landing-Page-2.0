# ⚙️ Configuração do Loader

## 🎛️ Opções Disponíveis

Em `AppLoader.tsx` linha 30-31:

```tsx
const ALWAYS_SHOW_LOADER = false  // true = sempre mostra (mesmo em prod)
const SKIP_LOADER = false         // true = nunca mostra (dev rápido)
```

## 📋 Casos de Uso

### 1️⃣ Desenvolvimento (padrão)
```tsx
ALWAYS_SHOW_LOADER = false
SKIP_LOADER = false
```
**Resultado:** Loader aparece toda vez que recarrega a página
**Uso:** Testar animações, ajustar timing

---

### 2️⃣ Dev Rápido (pular loader)
```tsx
ALWAYS_SHOW_LOADER = false
SKIP_LOADER = true
```
**Resultado:** Loader NUNCA aparece
**Uso:** Desenvolvimento rápido, testar conteúdo da página

---

### 3️⃣ Produção - Sempre Mostra
```tsx
ALWAYS_SHOW_LOADER = true
SKIP_LOADER = false
```
**Resultado:** Loader aparece sempre, mesmo em produção
**Uso:** Site com loader como parte da experiência (tipo Netflix)

---

### 4️⃣ Produção - Smart (recomendado)
```tsx
ALWAYS_SHOW_LOADER = false
SKIP_LOADER = false
```
**Resultado:**
- DEV: Loader toda vez
- PROD: Loader 1x por sessão

**Uso:** Melhor UX - loader só na primeira visita

---

## 🔄 Comportamento por Ambiente

| Configuração | DEV (npm run dev) | PROD (npm run build) |
|--------------|-------------------|----------------------|
| Default | ✅ Toda vez | ✅ 1x por sessão |
| SKIP_LOADER=true | ❌ Nunca | ❌ Nunca |
| ALWAYS_SHOW=true | ✅ Toda vez | ✅ Toda vez |

## 🧪 Testar Comportamento de Produção

### Limpar sessionStorage:

**Console do navegador:**
```javascript
sessionStorage.clear()
location.reload()
```

**Ou:**
```
F12 → Application → Session Storage → Clear All
```

### Build e testar:
```bash
npm run build
npm run start

# Abrir: http://localhost:3000
# 1ª visita: Mostra loader ✅
# 2ª visita: Pula loader ✅
# Nova aba: Mostra loader ✅
```

## 🎯 Recomendações

### Para Desenvolvimento:
```tsx
ALWAYS_SHOW_LOADER = false
SKIP_LOADER = false
```
👍 Ver loader toda vez para ajustar animações

### Para Produção:
```tsx
ALWAYS_SHOW_LOADER = false
SKIP_LOADER = false
```
👍 UX ideal - loader apenas na primeira impressão

### Para Demos/Apresentações:
```tsx
ALWAYS_SHOW_LOADER = true
SKIP_LOADER = false
```
👍 Sempre mostra o loader cinematográfico

## 🐛 Troubleshooting

### "Loader não aparece mais"

**Causa:** sessionStorage salvou que já viu
**Solução:**
```javascript
sessionStorage.removeItem('prisma-loader-seen')
// OU
sessionStorage.clear()
```

### "Loader aparece toda vez em produção"

**Causa:** `ALWAYS_SHOW_LOADER = true`
**Solução:** Mudar para `false`

### "Loader nunca aparece"

**Causa:** `SKIP_LOADER = true`
**Solução:** Mudar para `false`

### "Quero forçar loader agora (sem mexer no código)"

**Console:**
```javascript
sessionStorage.removeItem('prisma-loader-seen')
location.reload()
```

## 🎬 Atalhos do Navegador

### Chrome DevTools:

**Limpar tudo e recarregar:**
```
Ctrl/Cmd + Shift + Delete
→ Session Storage
→ Clear
→ Ctrl/Cmd + Shift + R
```

**Hard Reload (ignora cache):**
```
Ctrl/Cmd + Shift + R
```

**Empty Cache + Hard Reload:**
```
F12 (abrir DevTools)
Click direito no botão Reload
→ "Empty Cache and Hard Reload"
```

## 📝 Exemplo Completo

```tsx
// AppLoader.tsx

// Cenário 1: Fase de desenvolvimento
const ALWAYS_SHOW_LOADER = false  // Respeita env
const SKIP_LOADER = false         // Mostra loader

// Resultado:
// - npm run dev → Loader toda vez ✅
// - npm run build → Loader 1x por sessão ✅

---

// Cenário 2: Dev rápido (sem loader)
const ALWAYS_SHOW_LOADER = false
const SKIP_LOADER = true          // Pula loader

// Resultado:
// - npm run dev → Sem loader ✅
// - npm run build → Sem loader ✅

---

// Cenário 3: Loader obrigatório
const ALWAYS_SHOW_LOADER = true   // Força loader
const SKIP_LOADER = false

// Resultado:
// - npm run dev → Loader toda vez ✅
// - npm run build → Loader toda vez ✅
```

## 🚀 Deploy em Produção

### Vercel / Netlify / outros:

1. **Verifique configuração:**
   ```tsx
   ALWAYS_SHOW_LOADER = false  // ✅
   SKIP_LOADER = false         // ✅
   ```

2. **Build:**
   ```bash
   npm run build
   ```

3. **Resultado esperado:**
   - 1ª visita: Loader completo (3s)
   - 2ª+ visitas: Direto pro conteúdo
   - Nova sessão: Loader de novo

## 💡 Dica Pro

Para ter controle fino via URL params:

```tsx
// Adicionar no useEffect:
const urlParams = new URLSearchParams(window.location.search)
const forceLoader = urlParams.get('loader') === 'true'
const skipLoader = urlParams.get('loader') === 'false'

if (forceLoader) return // Mostra
if (skipLoader) {
  setLoadingPhase('ready')
  setRenderContent(true)
  return
}
```

**Uso:**
```
https://prisma.com/?loader=true   → Força loader
https://prisma.com/?loader=false  → Pula loader
https://prisma.com/               → Comportamento normal
```

---

**Configuração by Prisma Team** ⚙️
