'use client'

import { motion } from 'framer-motion'
import { useState } from 'react'

const agentFlows = [
  {
    title: '🟣 Agente WhatsApp - Recepção',
    description: 'Atendente mestre que recepciona, qualifica e direciona cada lead',
    user: "Olá! Gostaria de saber mais sobre os serviços da Prisma",
    bot: "Olá! 👋 Seja bem-vindo à Prisma. Antes de te direcionar, posso saber se você quer entender sobre estratégia completa, tráfego pago ou posicionamento digital?",
  },
  {
    title: '🟢 Agente WhatsApp - Vendedor',
    description: 'Consultor e closer que personaliza propostas e fecha negócios',
    user: "Quero entender sobre estratégia completa",
    bot: "Perfeito! Pelo que você respondeu, você se encaixa no modelo de Implementação Completa. Vou te enviar um vídeo explicativo de 1 min. Quer que eu te mostre como aplicar isso na sua empresa ainda essa semana?",
  },
  {
    title: '🔁 Agente WhatsApp - Follow-Up',
    description: 'Inteligência comercial que reativa leads e mantém relacionamento',
    user: "",
    bot: "Oi, João! Vi que você ainda não finalizou. Estamos com vagas limitadas para o mês. Temos novos casos de clientes que aumentaram 3x o faturamento. Quer ver?",
  },
  {
    title: '🧠 Agente Instagram - Engajamento',
    description: 'Transforma seguidores em leads ativos através de DMs automáticas',
    user: "quero saber mais",
    bot: "Perfeito! 👋 Posso te mandar um material que explica como funciona nossa estratégia? Te direciono direto pro WhatsApp onde podemos conversar melhor!",
  },
]

export default function Demo() {
  const [activeAgent, setActiveAgent] = useState(0)

  return (
    <section id="solucoes" className="py-32 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          viewport={{ once: true, margin: "-100px" }}
          className="text-center mb-16"
        >
          <motion.h2
            className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 px-4 leading-tight"
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            viewport={{ once: true }}
          >
            Agentes de IA <span className="gradient-text-animated">vendendo por você</span>
          </motion.h2>
          <p className="text-base sm:text-lg md:text-xl text-white/80 max-w-3xl mx-auto px-4 leading-relaxed">
            Veja como nossos agentes inteligentes <strong className="text-white">qualificam e convertem leads 24/7</strong> no automático
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Demo Chat Interface */}
          <motion.div
            initial={{ opacity: 0, x: -60, scale: 0.95 }}
            whileInView={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            viewport={{ once: true, margin: "-100px" }}
            className="order-2 lg:order-1"
          >
            <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-1 border border-white/10">
              <div className="bg-dark-light rounded-3xl overflow-hidden">
                {/* Chat Header */}
                <div className="bg-purple/20 backdrop-blur-sm px-6 py-4 border-b border-white/10">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-purple rounded-full flex items-center justify-center">
                      <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/>
                      </svg>
                    </div>
                    <div>
                      <div className="font-semibold">{agentFlows[activeAgent].title}</div>
                      <div className="text-sm text-white/60">Online • Automático</div>
                    </div>
                  </div>
                </div>

                {/* Chat Messages */}
                <div className="p-6 space-y-4 min-h-[400px] flex flex-col justify-center">
                  <motion.div
                    key={activeAgent}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    {agentFlows[activeAgent].user && (
                      <div className="flex justify-end mb-4">
                        <div className="bg-purple rounded-2xl rounded-tr-sm px-4 py-3 max-w-[80%]">
                          <p className="text-sm">{agentFlows[activeAgent].user}</p>
                        </div>
                      </div>
                    )}

                    {/* Bot Response */}
                    <div className="flex justify-start">
                      <div className="bg-white/10 rounded-2xl rounded-tl-sm px-4 py-3 max-w-[85%]">
                        <p className="text-sm text-white/90">{agentFlows[activeAgent].bot}</p>
                      </div>
                    </div>
                  </motion.div>
                </div>

                {/* Chat Input */}
                <div className="px-6 py-4 border-t border-white/10">
                  <div className="flex items-center space-x-2 bg-white/5 rounded-full px-4 py-3">
                    <input
                      type="text"
                      placeholder="Resposta automática em andamento..."
                      className="flex-1 bg-transparent outline-none text-sm text-white/40"
                      disabled
                    />
                    <div className="w-8 h-8 bg-purple/50 rounded-full flex items-center justify-center">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z"/>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Agent Selector */}
          <motion.div
            initial={{ opacity: 0, x: 60, scale: 0.95 }}
            whileInView={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            viewport={{ once: true, margin: "-100px" }}
            className="order-1 lg:order-2 space-y-3 md:space-y-4"
          >
            <h3 className="text-xl md:text-2xl font-bold mb-4 md:mb-6">Escolha um Agente</h3>
            {agentFlows.map((agent, index) => (
              <motion.button
                key={index}
                onClick={() => setActiveAgent(index)}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`w-full text-left p-4 md:p-6 rounded-2xl border transition-all ${
                  activeAgent === index
                    ? 'bg-purple/20 border-purple'
                    : 'bg-white/5 border-white/10 hover:border-white/20'
                }`}
              >
                <div className="flex items-start space-x-3 md:space-x-4">
                  <div className={`w-10 h-10 md:w-12 md:h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                    activeAgent === index ? 'bg-purple' : 'bg-white/10'
                  }`}>
                    <svg className="w-5 h-5 md:w-6 md:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold mb-1 md:mb-2 text-sm md:text-base leading-tight">{agent.title}</p>
                    <p className="text-xs md:text-sm text-white/70 leading-snug">{agent.description}</p>
                  </div>
                </div>
              </motion.button>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  )
}
