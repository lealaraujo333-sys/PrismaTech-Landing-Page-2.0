'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useState, useEffect } from 'react'
import Image from 'next/image'

interface LoaderVariantProps {
  onComplete?: () => void
}

/**
 * Loader Cinematográfico - Versão Premium
 * Inspirado em Netflix, Apple TV+ e HBO Max
 */
export default function LoaderVariant({ onComplete }: LoaderVariantProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [phase, setPhase] = useState<'intro' | 'reveal' | 'showcase' | 'pulse' | 'exit'>('intro')

  useEffect(() => {
    // Fase 1: Intro - Letterbox abre (0-0.8s)
    const introTimer = setTimeout(() => setPhase('reveal'), 800)

    // Fase 2: Reveal - Logo aparece com 3D (0.8-2.5s)
    const revealTimer = setTimeout(() => setPhase('showcase'), 2500)

    // Fase 3: Showcase - Logo rotaciona e pulsa (2.5-4.5s)
    const showcaseTimer = setTimeout(() => setPhase('pulse'), 4500)

    // Fase 4: Pulse - Efeitos finais (4.5-5.5s)
    const pulseTimer = setTimeout(() => setPhase('exit'), 5500)

    // Fase 5: Exit - Logo sai e transição (5.5-6.5s)
    const exitTimer = setTimeout(() => {
      setIsLoading(false)
      onComplete?.()
    }, 6500)

    return () => {
      clearTimeout(introTimer)
      clearTimeout(revealTimer)
      clearTimeout(showcaseTimer)
      clearTimeout(pulseTimer)
      clearTimeout(exitTimer)
    }
  }, [onComplete])

  return (
    <AnimatePresence mode="wait">
      {isLoading && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-black overflow-hidden"
        >
          {/* Cinematic letterbox bars - Enhanced */}
          <motion.div
            className="absolute top-0 left-0 right-0 bg-black z-20"
            initial={{ height: 0 }}
            animate={{
              height: phase === 'exit' ? 0 : '12vh'
            }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          />
          <motion.div
            className="absolute bottom-0 left-0 right-0 bg-black z-20"
            initial={{ height: 0 }}
            animate={{
              height: phase === 'exit' ? 0 : '12vh'
            }}
            transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          />

          {/* Dynamic background - Enhanced */}
          <motion.div
            className="absolute inset-0"
            initial={{ opacity: 0 }}
            animate={{
              opacity: phase === 'intro' ? 0 : phase === 'exit' ? 0 : 1,
            }}
            transition={{ duration: 1.2 }}
            style={{ willChange: 'opacity' }}
          >
            {/* Radial gradient pulse */}
            <motion.div
              className="absolute inset-0"
              animate={{
                background: [
                  'radial-gradient(circle at 50% 50%, rgba(135, 89, 242, 0.15) 0%, rgba(0, 0, 0, 1) 70%)',
                  'radial-gradient(circle at 50% 50%, rgba(135, 89, 242, 0.25) 0%, rgba(0, 0, 0, 1) 70%)',
                  'radial-gradient(circle at 50% 50%, rgba(135, 89, 242, 0.15) 0%, rgba(0, 0, 0, 1) 70%)',
                ]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              style={{ willChange: 'background' }}
            />

            {/* Rotating gradient orbs - Optimized */}
            <motion.div
              className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple/10 rounded-full blur-[120px]"
              animate={{
                x: [0, 100, 0],
                y: [0, -50, 0],
                scale: [1, 1.2, 1],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              style={{ willChange: 'transform' }}
            />
            <motion.div
              className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-light/10 rounded-full blur-[120px]"
              animate={{
                x: [0, -100, 0],
                y: [0, 50, 0],
                scale: [1.2, 1, 1.2],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 1.5
              }}
              style={{ willChange: 'transform' }}
            />
          </motion.div>

          {/* Main logo stage */}
          <div className="relative z-10 flex flex-col items-center">
            {/* Spotlight effect */}
            <motion.div
              className="absolute inset-0 blur-[150px] pointer-events-none"
              initial={{ scale: 0, opacity: 0 }}
              animate={{
                scale: phase === 'logo' ? [0, 2, 1.5] : 0,
                opacity: phase === 'logo' ? [0, 0.8, 0] : 0,
              }}
              transition={{
                duration: 2,
                times: [0, 0.5, 1],
                ease: [0.22, 1, 0.36, 1]
              }}
            >
              <div className="w-64 h-64 bg-purple" />
            </motion.div>

            {/* Logo container with 3D perspective - Ultra Complex */}
            <motion.div
              initial={{ scale: 0, opacity: 0, z: -1500, rotateX: 90, rotateY: -180 }}
              animate={{
                // Intro (hidden)
                scale: phase === 'intro' ? 0 :
                       // Reveal (appears)
                       phase === 'reveal' ? 1 :
                       // Showcase (normal)
                       phase === 'showcase' ? 1 :
                       // Pulse (bigger)
                       phase === 'pulse' ? 1.1 :
                       // Exit (explode)
                       1.5,

                opacity: phase === 'intro' ? 0 :
                         phase === 'exit' ? 0 : 1,

                z: phase === 'intro' ? -1500 :
                   phase === 'reveal' ? 0 :
                   phase === 'exit' ? 500 : 0,

                rotateX: phase === 'intro' ? 90 :
                         phase === 'reveal' ? [90, 0] :
                         phase === 'exit' ? -45 : 0,

                rotateY: phase === 'intro' ? -180 :
                         phase === 'reveal' ? [0, 0] :
                         phase === 'showcase' ? [0, 360] :
                         phase === 'pulse' ? 360 :
                         360,

                rotateZ: phase === 'pulse' ? [0, 10, -10, 0] : 0,
              }}
              transition={{
                scale: {
                  duration: phase === 'reveal' ? 1.5 :
                           phase === 'exit' ? 0.8 : 1,
                  ease: [0.22, 1, 0.36, 1]
                },
                opacity: {
                  duration: phase === 'exit' ? 0.6 : 1
                },
                z: {
                  duration: phase === 'exit' ? 0.8 : 1.5,
                  ease: [0.22, 1, 0.36, 1]
                },
                rotateX: {
                  duration: 1.2,
                  ease: [0.22, 1, 0.36, 1]
                },
                rotateY: {
                  duration: phase === 'showcase' ? 2.5 : 1,
                  ease: "easeInOut"
                },
                rotateZ: {
                  duration: 1,
                  ease: "easeInOut",
                  repeat: phase === 'pulse' ? Infinity : 0,
                },
              }}
              style={{
                perspective: '2000px',
                transformStyle: 'preserve-3d',
                willChange: 'transform, opacity'
              }}
              className="relative"
            >
              {/* Glow rings */}
              <motion.div
                className="absolute inset-0 rounded-full"
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.5, 0, 0.5],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeOut"
                }}
              >
                <div className="w-full h-full border-4 border-purple/50 rounded-full" />
              </motion.div>

              {/* Logo Container - Clean & Transparent */}
              <motion.div
                className="relative w-52 h-52 md:w-64 md:h-64 flex items-center justify-center"
                animate={{
                  filter: [
                    'drop-shadow(0 0 40px rgba(135, 89, 242, 0.6))',
                    'drop-shadow(0 0 60px rgba(135, 89, 242, 0.9))',
                    'drop-shadow(0 0 40px rgba(135, 89, 242, 0.6))',
                  ]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                style={{ transformStyle: 'preserve-3d', willChange: 'filter' }}
              >
                {/* Prisma Logo - No Background */}
                <motion.div
                  className="relative w-full h-full"
                  animate={{
                    scale: [0.95, 1.05, 0.95],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  style={{ transform: 'translateZ(50px)', willChange: 'transform' }}
                >
                  <Image
                    src="/logo_white.png"
                    alt="Prisma"
                    fill
                    priority
                    quality={100}
                    className="object-contain"
                    style={{
                      filter: 'brightness(1.1) contrast(1.1)',
                    }}
                  />
                </motion.div>
              </motion.div>
            </motion.div>

            {/* Brand name */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{
                opacity: phase === 'logo' ? 1 : 0,
                y: phase === 'logo' ? 0 : 40,
              }}
              transition={{
                duration: 0.8,
                delay: 0.5,
                ease: [0.22, 1, 0.36, 1]
              }}
              className="mt-10"
            >
              <motion.h1
                className="text-5xl md:text-6xl font-bold tracking-wider"
                animate={{
                  backgroundImage: [
                    'linear-gradient(90deg, #8759f2 0%, #9d7ff5 50%, #8759f2 100%)',
                    'linear-gradient(90deg, #9d7ff5 0%, #8759f2 50%, #9d7ff5 100%)',
                    'linear-gradient(90deg, #8759f2 0%, #9d7ff5 50%, #8759f2 100%)',
                  ],
                }}
                style={{
                  backgroundClip: 'text',
                  WebkitBackgroundClip: 'text',
                  color: 'transparent',
                  backgroundSize: '200% 100%',
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "linear"
                }}
              >
                PRISMA
              </motion.h1>
            </motion.div>
          </div>

          {/* Subtle grid pattern */}
          <div className="absolute inset-0 opacity-[0.02] pointer-events-none"
            style={{
              backgroundImage: `
                linear-gradient(rgba(135, 89, 242, 0.5) 1px, transparent 1px),
                linear-gradient(90deg, rgba(135, 89, 242, 0.5) 1px, transparent 1px)
              `,
              backgroundSize: '50px 50px'
            }}
          />

          {/* Vignette overlay */}
          <div className="absolute inset-0 pointer-events-none"
            style={{
              background: 'radial-gradient(circle at center, transparent 0%, rgba(0, 0, 0, 0.8) 100%)'
            }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  )
}
