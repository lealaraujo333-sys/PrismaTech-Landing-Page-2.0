'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-dark/80 backdrop-blur-lg border-b border-white/10' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-12">
            <a href="#" className="flex items-center space-x-3">
              <img src="/logo.png" alt="Prisma" className="h-10 w-auto" />
            </a>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#servicos" className="text-sm text-white/70 hover:text-white transition-colors">
                Serviços
              </a>
              <a href="#solucoes" className="text-sm text-white/70 hover:text-white transition-colors">
                Soluções
              </a>
              <a href="#resultados" className="text-sm text-white/70 hover:text-white transition-colors">
                Resultados
              </a>
              <a href="#planos" className="text-sm text-white/70 hover:text-white transition-colors">
                Planos
              </a>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <a
              href="#contato"
              className="hidden md:block text-sm text-white/70 hover:text-white transition-colors"
            >
              Contato
            </a>
            <a
              href="https://wa.me/5511999999999?text=Olá,%20gostaria%20de%20saber%20mais%20sobre%20os%20serviços%20da%20Prisma"
              target="_blank"
              rel="noopener noreferrer"
              className="px-6 py-2.5 bg-purple rounded-full text-sm font-medium hover:bg-purple-light transition-all hover:scale-105"
            >
              Falar no WhatsApp
            </a>
          </div>
        </div>
      </div>
    </motion.nav>
  )
}
