'use client'

import { motion } from 'framer-motion'
import ParticleBackground from './ParticleBackground'

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Particle Background */}
      <ParticleBackground />

      {/* Gradient Background Orbs */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.3, 0.6, 0.3],
            x: [0, 50, 0],
            y: [0, -30, 0],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple/30 rounded-full blur-[120px] animate-pulse-slow"
        />
        <motion.div
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.2, 0.5, 0.2],
            x: [0, -40, 0],
            y: [0, 50, 0],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-purple-light/20 rounded-full blur-[150px]"
        />
        <motion.div
          animate={{
            scale: [1, 1.4, 1],
            opacity: [0.15, 0.4, 0.15],
            x: [0, 30, 0],
          }}
          transition={{
            duration: 18,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple/15 rounded-full blur-[180px]"
        />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
        >
          <motion.h1
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-bold mb-6 leading-[1.1] px-4"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
          >
            Quando crescer <br className="hidden sm:block" />fica caro, <br />
            <span className="gradient-text-animated">a Prisma vira o jogo</span>
          </motion.h1>
          <motion.p
            className="text-base sm:text-lg md:text-xl lg:text-2xl text-white/80 mb-10 max-w-3xl mx-auto px-6 leading-relaxed"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6, ease: [0.22, 1, 0.36, 1] }}
          >
            <strong className="text-white">Crescer é fácil. Lucrar crescendo é raro.</strong><br className="mb-2"/>
            Transformamos empresas que faturam entre R$ 600k e R$ 4M/ano em <span className="text-white">máquinas de crescimento lucrativo</span>.
          </motion.p>
          <motion.div
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8, ease: [0.22, 1, 0.36, 1] }}
          >
            <motion.a
              href="https://wa.me/5511999999999?text=Olá,%20quero%20descobrir%20como%20crescer%20lucrando"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.08, boxShadow: "0 20px 60px rgba(135, 89, 242, 0.5)" }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 400, damping: 17 }}
              className="w-full sm:w-auto px-8 py-4 bg-purple rounded-full text-base sm:text-lg font-semibold hover:bg-purple-light transition-colors shadow-lg shadow-purple/50"
            >
              Quero Virar o Jogo
            </motion.a>
            <motion.a
              href="#manifesto"
              whileHover={{ scale: 1.05, backgroundColor: "rgba(255, 255, 255, 0.15)" }}
              whileTap={{ scale: 0.95 }}
              transition={{ type: "spring", stiffness: 400, damping: 17 }}
              className="w-full sm:w-auto px-8 py-4 bg-white/10 backdrop-blur-sm rounded-full text-base sm:text-lg font-medium hover:bg-white/20 transition-colors border border-white/20"
            >
              Ver o Manifesto
            </motion.a>
          </motion.div>
        </motion.div>

        {/* Hero Visual Cards */}
        <motion.div
          initial={{ opacity: 0, y: 60, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 1.2, delay: 1, ease: [0.22, 1, 0.36, 1] }}
          className="mt-16 md:mt-20 relative px-4"
        >
          <div className="relative mx-auto max-w-5xl">
            {/* Gradient overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-dark via-dark/50 to-transparent z-10 pointer-events-none" />

            {/* Cards Container */}
            <div className="relative">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6 mb-6 md:mb-8">
                {/* Card 1 - Estratégia */}
                <motion.div
                  initial={{ opacity: 0, y: 40, rotateX: 15 }}
                  animate={{ opacity: 1, y: 0, rotateX: 0 }}
                  transition={{ duration: 0.8, delay: 1.2, ease: [0.22, 1, 0.36, 1] }}
                  whileHover={{
                    y: -12,
                    scale: 1.05,
                    rotateY: 5,
                    transition: { duration: 0.3, ease: [0.22, 1, 0.36, 1] }
                  }}
                  className="group relative"
                  style={{ perspective: '1000px' }}
                >
                  <div className="relative bg-gradient-to-br from-purple/20 via-purple/10 to-transparent backdrop-blur-xl rounded-2xl md:rounded-3xl p-6 md:p-8 border border-purple/30 hover:border-purple/60 transition-all duration-500 overflow-hidden">
                    {/* Animated glow effect */}
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-br from-purple/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                      animate={{
                        background: [
                          'radial-gradient(circle at 0% 0%, rgba(135, 89, 242, 0.3) 0%, transparent 50%)',
                          'radial-gradient(circle at 100% 100%, rgba(135, 89, 242, 0.3) 0%, transparent 50%)',
                          'radial-gradient(circle at 0% 0%, rgba(135, 89, 242, 0.3) 0%, transparent 50%)',
                        ]
                      }}
                      transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                    />

                    <div className="relative z-10">
                      <motion.div
                        className="w-14 h-14 md:w-16 md:h-16 mx-auto mb-4 md:mb-5 bg-purple/30 rounded-2xl flex items-center justify-center group-hover:bg-purple/50 transition-all duration-500"
                        whileHover={{ rotate: [0, -10, 10, 0], transition: { duration: 0.5 } }}
                      >
                        <svg className="w-7 h-7 md:w-8 md:h-8 text-purple-light" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                        </svg>
                      </motion.div>
                      <p className="text-base md:text-lg font-semibold text-white/90 text-center">Estratégia</p>
                    </div>
                  </div>
                </motion.div>

                {/* Card 2 - Automação */}
                <motion.div
                  initial={{ opacity: 0, y: 40, rotateX: 15 }}
                  animate={{ opacity: 1, y: 0, rotateX: 0 }}
                  transition={{ duration: 0.8, delay: 1.35, ease: [0.22, 1, 0.36, 1] }}
                  whileHover={{
                    y: -12,
                    scale: 1.05,
                    rotateY: 5,
                    transition: { duration: 0.3, ease: [0.22, 1, 0.36, 1] }
                  }}
                  className="group relative"
                  style={{ perspective: '1000px' }}
                >
                  <div className="relative bg-gradient-to-br from-purple/20 via-purple/10 to-transparent backdrop-blur-xl rounded-2xl md:rounded-3xl p-6 md:p-8 border border-purple/30 hover:border-purple/60 transition-all duration-500 overflow-hidden">
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-br from-purple/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                      animate={{
                        background: [
                          'radial-gradient(circle at 100% 0%, rgba(135, 89, 242, 0.3) 0%, transparent 50%)',
                          'radial-gradient(circle at 0% 100%, rgba(135, 89, 242, 0.3) 0%, transparent 50%)',
                          'radial-gradient(circle at 100% 0%, rgba(135, 89, 242, 0.3) 0%, transparent 50%)',
                        ]
                      }}
                      transition={{ duration: 3, repeat: Infinity, ease: "linear", delay: 1 }}
                    />

                    <div className="relative z-10">
                      <motion.div
                        className="w-14 h-14 md:w-16 md:h-16 mx-auto mb-4 md:mb-5 bg-purple/30 rounded-2xl flex items-center justify-center group-hover:bg-purple/50 transition-all duration-500"
                        whileHover={{ rotate: [0, -10, 10, 0], transition: { duration: 0.5 } }}
                      >
                        <svg className="w-7 h-7 md:w-8 md:h-8 text-purple-light" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                        </svg>
                      </motion.div>
                      <p className="text-base md:text-lg font-semibold text-white/90 text-center">Automação</p>
                    </div>
                  </div>
                </motion.div>

                {/* Card 3 - Crescimento */}
                <motion.div
                  initial={{ opacity: 0, y: 40, rotateX: 15 }}
                  animate={{ opacity: 1, y: 0, rotateX: 0 }}
                  transition={{ duration: 0.8, delay: 1.5, ease: [0.22, 1, 0.36, 1] }}
                  whileHover={{
                    y: -12,
                    scale: 1.05,
                    rotateY: 5,
                    transition: { duration: 0.3, ease: [0.22, 1, 0.36, 1] }
                  }}
                  className="group relative sm:col-span-1 col-span-1"
                  style={{ perspective: '1000px' }}
                >
                  <div className="relative bg-gradient-to-br from-purple/20 via-purple/10 to-transparent backdrop-blur-xl rounded-2xl md:rounded-3xl p-6 md:p-8 border border-purple/30 hover:border-purple/60 transition-all duration-500 overflow-hidden">
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-br from-purple/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                      animate={{
                        background: [
                          'radial-gradient(circle at 50% 50%, rgba(135, 89, 242, 0.3) 0%, transparent 50%)',
                          'radial-gradient(circle at 100% 0%, rgba(135, 89, 242, 0.3) 0%, transparent 50%)',
                          'radial-gradient(circle at 50% 50%, rgba(135, 89, 242, 0.3) 0%, transparent 50%)',
                        ]
                      }}
                      transition={{ duration: 3, repeat: Infinity, ease: "linear", delay: 2 }}
                    />

                    <div className="relative z-10">
                      <motion.div
                        className="w-14 h-14 md:w-16 md:h-16 mx-auto mb-4 md:mb-5 bg-purple/30 rounded-2xl flex items-center justify-center group-hover:bg-purple/50 transition-all duration-500"
                        whileHover={{ rotate: [0, -10, 10, 0], transition: { duration: 0.5 } }}
                      >
                        <svg className="w-7 h-7 md:w-8 md:h-8 text-purple-light" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                      </motion.div>
                      <p className="text-base md:text-lg font-semibold text-white/90 text-center">Crescimento</p>
                    </div>
                  </div>
                </motion.div>
              </div>

              {/* Bottom tagline */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1.7, ease: [0.22, 1, 0.36, 1] }}
                className="text-center"
              >
                <p className="text-sm md:text-base lg:text-lg text-white/50 font-medium">
                  Marketing + Tecnologia + IA
                </p>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
