'use client'

import { motion, AnimatePresence } from 'framer-motion'
import { useState, useEffect } from 'react'
import { ApolloClient, InMemoryCache, gql } from '@apollo/client'

interface DashboardLoaderProps {
  onComplete?: () => void
}

const INIT_QUERY = gql`
  query InitDashboard {
    agents {
      id
      name
      status
      type
    }
  }
`

const loadingStages = [
  { progress: 0, text: 'Conectando ao servidor...' },
  { progress: 20, text: 'Autenticando usuário...' },
  { progress: 40, text: 'Carregando agentes de IA...' },
  { progress: 60, text: 'Sincronizando campanhas...' },
  { progress: 80, text: 'Preparando analytics...' },
  { progress: 100, text: 'Finalizando...' },
]

export default function DashboardLoader({ onComplete }: DashboardLoaderProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [progress, setProgress] = useState(0)
  const [currentStage, setCurrentStage] = useState(0)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false

    async function initializeDashboard() {
      try {
        const client = new ApolloClient({
          uri: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/graphql',
          cache: new InMemoryCache(),
        })

        // Progress through loading stages
        for (let i = 0; i < loadingStages.length; i++) {
          if (cancelled) return

          setCurrentStage(i)
          setProgress(loadingStages[i].progress)

          // Fetch real data at stage 2 (agents)
          if (i === 2) {
            try {
              await client.query({ query: INIT_QUERY })
            } catch (err) {
              console.warn('API not ready yet, continuing...', err)
              // Continue anyway - API might not be ready yet
            }
          }

          await new Promise(resolve => setTimeout(resolve, 400 + Math.random() * 300))
        }

        // Complete
        if (!cancelled) {
          setTimeout(() => {
            setIsLoading(false)
            onComplete?.()
          }, 400)
        }
      } catch (err) {
        console.error('Dashboard initialization error:', err)
        if (!cancelled) {
          setError('Erro ao conectar com o servidor')
          // Still complete after error
          setTimeout(() => {
            setIsLoading(false)
            onComplete?.()
          }, 2000)
        }
      }
    }

    initializeDashboard()

    return () => {
      cancelled = true
    }
  }, [onComplete])

  return (
    <AnimatePresence mode="wait">
      {isLoading && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="fixed inset-0 z-[9999] flex items-center justify-center bg-dark overflow-hidden"
        >
          {/* Animated grid background */}
          <div className="absolute inset-0 opacity-20">
            <div className="absolute inset-0" style={{
              backgroundImage: `
                linear-gradient(rgba(135, 89, 242, 0.1) 1px, transparent 1px),
                linear-gradient(90deg, rgba(135, 89, 242, 0.1) 1px, transparent 1px)
              `,
              backgroundSize: '50px 50px',
            }} />
          </div>

          {/* Animated particles */}
          <div className="absolute inset-0 overflow-hidden">
            {[...Array(30)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-purple/30 rounded-full"
                initial={{
                  x: Math.random() * (typeof window !== 'undefined' ? window.innerWidth : 1000),
                  y: Math.random() * (typeof window !== 'undefined' ? window.innerHeight : 800),
                  scale: 0,
                }}
                animate={{
                  y: [null, -150],
                  scale: [0, Math.random() * 2, 0],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 2 + Math.random() * 2,
                  delay: Math.random() * 2,
                  repeat: Infinity,
                  ease: "easeOut"
                }}
              />
            ))}
          </div>

          {/* Logo and Loader */}
          <div className="relative z-10 flex flex-col items-center">
            {/* Prisma Logo */}
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              className="mb-8"
            >
              <motion.h1
                className="text-7xl md:text-8xl font-bold gradient-text-animated"
                animate={{
                  textShadow: [
                    '0 0 20px rgba(135, 89, 242, 0.3)',
                    '0 0 40px rgba(135, 89, 242, 0.6)',
                    '0 0 20px rgba(135, 89, 242, 0.3)',
                  ],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                PRISMA
              </motion.h1>
              <motion.p
                className="text-center text-sm text-purple-light mt-2 tracking-wider"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                Marketing Intelligence
              </motion.p>
            </motion.div>

            {/* Rotating cube structure */}
            <motion.div
              className="relative w-32 h-32 md:w-40 md:h-40"
              animate={{
                rotateX: [0, 360],
                rotateY: [0, 360],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "linear"
              }}
              style={{ perspective: '1000px', transformStyle: 'preserve-3d' }}
            >
              {/* Cube faces */}
              {[
                { rotate: 'rotateY(0deg)', translate: 'translateZ(80px)' },
                { rotate: 'rotateY(180deg)', translate: 'translateZ(80px)' },
                { rotate: 'rotateY(90deg)', translate: 'translateZ(80px)' },
                { rotate: 'rotateY(-90deg)', translate: 'translateZ(80px)' },
                { rotate: 'rotateX(90deg)', translate: 'translateZ(80px)' },
                { rotate: 'rotateX(-90deg)', translate: 'translateZ(80px)' },
              ].map((face, i) => (
                <motion.div
                  key={i}
                  className="absolute inset-0 border-2 border-purple/30 bg-purple/5 backdrop-blur-sm"
                  style={{
                    transform: `${face.rotate} ${face.translate}`,
                    transformStyle: 'preserve-3d',
                  }}
                  animate={{
                    borderColor: [
                      'rgba(135, 89, 242, 0.3)',
                      'rgba(167, 139, 250, 0.6)',
                      'rgba(135, 89, 242, 0.3)',
                    ],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: i * 0.1
                  }}
                />
              ))}

              {/* Inner glowing core */}
              <motion.div
                className="absolute inset-0 flex items-center justify-center"
                style={{ transformStyle: 'preserve-3d' }}
              >
                <motion.div
                  className="w-12 h-12 rounded-full bg-purple"
                  animate={{
                    scale: [1, 1.5, 1],
                    opacity: [0.5, 1, 0.5],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  style={{
                    boxShadow: '0 0 60px rgba(135, 89, 242, 0.8)',
                  }}
                />
              </motion.div>
            </motion.div>

            {/* Loading text */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.8,
                delay: 0.5,
                ease: [0.22, 1, 0.36, 1]
              }}
              className="text-center mt-12"
            >
              <motion.h2
                className="text-2xl md:text-3xl font-bold gradient-text-animated mb-4"
              >
                Carregando Dashboard
              </motion.h2>

              {/* Progress bar */}
              <div className="w-64 h-2 bg-dark-border rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-purple via-purple-light to-purple rounded-full"
                  initial={{ width: '0%' }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.3 }}
                  style={{
                    boxShadow: '0 0 20px rgba(135, 89, 242, 0.6)',
                  }}
                />
              </div>

              <motion.p
                className="text-sm text-gray-400 mt-4"
                animate={{
                  opacity: [0.5, 1, 0.5],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                {progress}% • {loadingStages[currentStage]?.text || 'Carregando...'}
              </motion.p>

              {error && (
                <motion.p
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-sm text-orange-400 mt-2"
                >
                  {error}
                </motion.p>
              )}
            </motion.div>
          </div>

          {/* Cinematic vignette */}
          <div className="absolute inset-0 pointer-events-none">
            <div className="w-full h-full bg-gradient-radial from-transparent via-transparent to-black opacity-50" />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
