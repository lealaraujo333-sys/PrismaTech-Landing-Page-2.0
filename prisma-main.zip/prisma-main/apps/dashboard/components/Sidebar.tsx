'use client'

import { motion } from 'framer-motion'
import { Home, BarChart3, Target, Bot, Settings, LogOut } from 'lucide-react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

const menuItems = [
  { icon: Home, label: 'Visão Geral', href: '/dashboard' },
  { icon: BarChart3, label: 'Analytics', href: '/analytics' },
  { icon: Target, label: 'Campanhas', href: '/campaigns' },
  { icon: Bot, label: 'Agentes de IA', href: '/agents' },
  { icon: Settings, label: 'Configurações', href: '/settings' },
]

export default function Sidebar() {
  const pathname = usePathname()

  return (
    <motion.aside
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="fixed left-0 top-0 h-screen w-64 glass-effect-strong border-r border-dark-border p-6 flex flex-col"
    >
      {/* Logo */}
      <div className="mb-12">
        <h1 className="text-3xl font-bold gradient-text">PRISMA</h1>
        <p className="text-xs text-gray-400 mt-1">Marketing Intelligence</p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-2">
        {menuItems.map((item, index) => {
          const isActive = pathname === item.href

          return (
            <motion.div
              key={item.label}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
            >
              <Link
                href={item.href}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  isActive
                    ? 'bg-purple/20 text-purple-light border border-purple/30'
                    : 'text-gray-400 hover:bg-dark-border hover:text-white'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            </motion.div>
          )
        })}
      </nav>

      {/* User Profile */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        className="mt-auto pt-6 border-t border-dark-border"
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple to-purple-light flex items-center justify-center font-bold">
            JD
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium">John Doe</p>
            <p className="text-xs text-gray-400">Acme Corp</p>
          </div>
        </div>
        <button className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors w-full">
          <LogOut className="w-4 h-4" />
          <span>Sair</span>
        </button>
      </motion.div>
    </motion.aside>
  )
}
