'use client'

import { motion } from 'framer-motion'
import { Activity, TrendingUp, AlertTriangle, Users, DollarSign, Target } from 'lucide-react'
import StatsCard from './StatsCard'
import AlertsPanel from './AlertsPanel'
import CampaignsTable from './CampaignsTable'
import MetricsChart from './MetricsChart'
import Sidebar from './Sidebar'

export default function MainDashboard() {
  return (
    <div className="min-h-screen bg-dark flex">
      <Sidebar />

      <main className="flex-1 p-8 ml-64">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold gradient-text mb-2">
            Visão Geral do Dashboard
          </h1>
          <p className="text-gray-400">
            Analytics em tempo real e insights impulsionados por IA
          </p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
          <StatsCard
            icon={<DollarSign className="w-6 h-6" />}
            title="Investimento Total"
            value="R$ 45.230"
            change="+12,5%"
            positive={false}
            delay={0.1}
          />
          <StatsCard
            icon={<TrendingUp className="w-6 h-6" />}
            title="Receita"
            value="R$ 156.840"
            change="+23,8%"
            positive={true}
            delay={0.2}
          />
          <StatsCard
            icon={<Target className="w-6 h-6" />}
            title="ROAS"
            value="3,47x"
            change="+8,3%"
            positive={true}
            delay={0.3}
          />
          <StatsCard
            icon={<Users className="w-6 h-6" />}
            title="Conversões"
            value="1.248"
            change="+15,2%"
            positive={true}
            delay={0.4}
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Metrics Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="lg:col-span-2 glass-effect-strong rounded-2xl p-6"
          >
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <Activity className="w-6 h-6 text-purple" />
              Métricas de Performance
            </h2>
            <MetricsChart />
          </motion.div>

          {/* Alerts Panel */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="glass-effect-strong rounded-2xl p-6"
          >
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
              <AlertTriangle className="w-6 h-6 text-purple" />
              Alertas de IA
            </h2>
            <AlertsPanel />
          </motion.div>
        </div>

        {/* Campaigns Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
          className="glass-effect-strong rounded-2xl p-6"
        >
          <h2 className="text-2xl font-bold mb-6">Campanhas Ativas</h2>
          <CampaignsTable />
        </motion.div>
      </main>
    </div>
  )
}
