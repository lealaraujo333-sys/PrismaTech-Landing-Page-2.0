'use client'

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'

const mockData = [
  { date: 'Jan 1', spend: 450, revenue: 1580, conversions: 42 },
  { date: 'Jan 2', spend: 520, revenue: 1820, conversions: 48 },
  { date: 'Jan 3', spend: 490, revenue: 1650, conversions: 44 },
  { date: 'Jan 4', spend: 580, revenue: 2100, conversions: 56 },
  { date: 'Jan 5', spend: 610, revenue: 2250, conversions: 61 },
  { date: 'Jan 6', spend: 540, revenue: 1950, conversions: 52 },
  { date: 'Jan 7', spend: 590, revenue: 2180, conversions: 58 },
]

export default function MetricsChart() {
  return (
    <div className="h-[350px]">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={mockData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1F1F29" />
          <XAxis
            dataKey="date"
            stroke="#6B7280"
            style={{ fontSize: '12px' }}
          />
          <YAxis
            stroke="#6B7280"
            style={{ fontSize: '12px' }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#131318',
              border: '1px solid #1F1F29',
              borderRadius: '8px',
            }}
          />
          <Legend />
          <Line
            type="monotone"
            dataKey="revenue"
            stroke="#10B981"
            strokeWidth={3}
            dot={{ fill: '#10B981', r: 4 }}
            activeDot={{ r: 6 }}
            name="Receita (R$)"
          />
          <Line
            type="monotone"
            dataKey="spend"
            stroke="#8759F2"
            strokeWidth={3}
            dot={{ fill: '#8759F2', r: 4 }}
            activeDot={{ r: 6 }}
            name="Investimento (R$)"
          />
          <Line
            type="monotone"
            dataKey="conversions"
            stroke="#A78BFA"
            strokeWidth={3}
            dot={{ fill: '#A78BFA', r: 4 }}
            activeDot={{ r: 6 }}
            name="Conversões"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
