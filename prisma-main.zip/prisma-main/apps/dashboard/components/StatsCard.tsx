'use client'

import { motion } from 'framer-motion'
import { TrendingUp, TrendingDown } from 'lucide-react'

interface StatsCardProps {
  icon: React.ReactNode
  title: string
  value: string
  change: string
  positive?: boolean
  delay?: number
}

export default function StatsCard({ icon, title, value, change, positive = true, delay = 0 }: StatsCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ scale: 1.02, y: -5 }}
      className="glass-effect-strong rounded-2xl p-6 relative overflow-hidden group cursor-pointer"
    >
      {/* Animated gradient background on hover */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-purple/10 to-purple-light/10 opacity-0 group-hover:opacity-100 transition-opacity"
        animate={{
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="p-3 rounded-xl bg-purple/20 text-purple-light">
            {icon}
          </div>
          <div className={`flex items-center gap-1 text-sm font-semibold ${positive ? 'text-green-400' : 'text-red-400'}`}>
            {positive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            {change}
          </div>
        </div>

        <h3 className="text-gray-400 text-sm mb-2">{title}</h3>
        <p className="text-3xl font-bold">{value}</p>
      </div>
    </motion.div>
  )
}
