'use client'

import { motion } from 'framer-motion'
import { TrendingUp, TrendingDown } from 'lucide-react'

const mockCampaigns = [
  {
    id: 1,
    name: 'Black Friday 2024 - Lançamento de Produto',
    status: 'Ativa',
    spend: 'R$ 12.450',
    revenue: 'R$ 43.200',
    roas: '3,47x',
    conversions: 486,
    trend: 'up',
  },
  {
    id: 2,
    name: 'Geração de Leads Q1',
    status: 'Ativa',
    spend: 'R$ 8.920',
    revenue: 'R$ 28.650',
    roas: '3,21x',
    conversions: 352,
    trend: 'up',
  },
  {
    id: 3,
    name: 'Campanha de Branding',
    status: 'Ativa',
    spend: 'R$ 5.680',
    revenue: 'R$ 14.230',
    roas: '2,51x',
    conversions: 189,
    trend: 'down',
  },
]

const statusColors = {
  Ativa: 'text-green-400 bg-green-400/20',
  Pausada: 'text-yellow-400 bg-yellow-400/20',
  Finalizada: 'text-gray-400 bg-gray-400/20',
}

export default function CampaignsTable() {
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-dark-border">
            <th className="text-left py-4 px-4 text-sm font-semibold text-gray-400">Campanha</th>
            <th className="text-left py-4 px-4 text-sm font-semibold text-gray-400">Status</th>
            <th className="text-right py-4 px-4 text-sm font-semibold text-gray-400">Investimento</th>
            <th className="text-right py-4 px-4 text-sm font-semibold text-gray-400">Receita</th>
            <th className="text-right py-4 px-4 text-sm font-semibold text-gray-400">ROAS</th>
            <th className="text-right py-4 px-4 text-sm font-semibold text-gray-400">Conversões</th>
            <th className="text-right py-4 px-4 text-sm font-semibold text-gray-400">Tendência</th>
          </tr>
        </thead>
        <tbody>
          {mockCampaigns.map((campaign, index) => (
            <motion.tr
              key={campaign.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="border-b border-dark-border/50 hover:bg-dark-border/30 transition-colors cursor-pointer"
            >
              <td className="py-4 px-4">
                <div className="font-medium">{campaign.name}</div>
              </td>
              <td className="py-4 px-4">
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${statusColors[campaign.status as keyof typeof statusColors]}`}>
                  {campaign.status}
                </span>
              </td>
              <td className="py-4 px-4 text-right font-semibold">{campaign.spend}</td>
              <td className="py-4 px-4 text-right font-semibold text-green-400">{campaign.revenue}</td>
              <td className="py-4 px-4 text-right font-semibold text-purple-light">{campaign.roas}</td>
              <td className="py-4 px-4 text-right">{campaign.conversions}</td>
              <td className="py-4 px-4 text-right">
                {campaign.trend === 'up' ? (
                  <TrendingUp className="w-5 h-5 text-green-400 ml-auto" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-red-400 ml-auto" />
                )}
              </td>
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
