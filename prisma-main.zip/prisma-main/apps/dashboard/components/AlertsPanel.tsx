'use client'

import { motion } from 'framer-motion'
import { AlertCircle, CheckCircle, XCircle } from 'lucide-react'

const mockAlerts = [
  {
    id: 1,
    type: 'HIGH_CPC',
    severity: 'HIGH',
    title: 'Pico de CPC Detectado',
    message: 'Campanha "Black Friday" CPC aumentou 2,1x',
    time: 'há 5 min',
  },
  {
    id: 2,
    type: 'LOW_CTR',
    severity: 'MEDIUM',
    title: 'Queda no CTR',
    message: 'Geração de Leads Q1 CTR caiu 23%',
    time: 'há 1 hora',
  },
  {
    id: 3,
    type: 'LEAD_QUALITY',
    severity: 'LOW',
    title: 'Novo Lead Qualificado',
    message: 'Lead de alta qualidade via WhatsApp',
    time: 'há 2 horas',
  },
]

const severityColors = {
  CRITICAL: 'text-red-500 bg-red-500/20',
  HIGH: 'text-orange-500 bg-orange-500/20',
  MEDIUM: 'text-yellow-500 bg-yellow-500/20',
  LOW: 'text-blue-500 bg-blue-500/20',
}

export default function AlertsPanel() {
  return (
    <div className="space-y-4">
      {mockAlerts.map((alert, index) => (
        <motion.div
          key={alert.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
          className="glass-effect rounded-xl p-4 hover:bg-dark-border/50 transition-colors cursor-pointer group"
        >
          <div className="flex items-start gap-3">
            <div className={`p-2 rounded-lg ${severityColors[alert.severity as keyof typeof severityColors]}`}>
              <AlertCircle className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold mb-1 group-hover:text-purple-light transition-colors">
                {alert.title}
              </h4>
              <p className="text-sm text-gray-400 mb-2">{alert.message}</p>
              <div className="flex items-center justify-between">
                <span className="text-xs text-gray-500">{alert.time}</span>
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="text-xs text-green-400 hover:text-green-300">
                    <CheckCircle className="w-4 h-4" />
                  </button>
                  <button className="text-xs text-red-400 hover:text-red-300">
                    <XCircle className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      ))}

      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="w-full py-3 rounded-xl border border-dark-border hover:border-purple/50 text-sm text-gray-400 hover:text-white transition-colors"
      >
        Ver Todos os Alertas
      </motion.button>
    </div>
  )
}
