'use client'

import { motion } from 'framer-motion'
import Sidebar from '@/components/Sidebar'
import { TrendingUp, DollarSign, Target, Users, Calendar, Download } from 'lucide-react'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from 'recharts'

// Mock data baseado no prisma.md - ROI Analytics
const performanceData = [
  { mes: 'Jan', investimento: 3800, receita: 11400, leads: 42, conversoes: 12 },
  { mes: 'Fev', investimento: 3800, receita: 13300, leads: 56, conversoes: 16 },
  { mes: 'Mar', investimento: 3800, receita: 15200, leads: 68, conversoes: 19 },
  { mes: 'Abr', investimento: 3800, receita: 18900, leads: 78, conversoes: 24 },
  { mes: 'Mai', investimento: 3800, receita: 22800, leads: 89, conversoes: 28 },
  { mes: 'Jun', investimento: 3800, receita: 26600, leads: 102, conversoes: 34 },
]

const roiData = [
  { mes: 'Jan', roas: 3.0 },
  { mes: 'Fev', roas: 3.5 },
  { mes: 'Mar', roas: 4.0 },
  { mes: 'Abr', roas: 4.97 },
  { mes: 'Mai', roas: 6.0 },
  { mes: 'Jun', roas: 7.0 },
]

const channelData = [
  { name: 'Facebook Ads', value: 45, color: '#8B5CF6' },
  { name: 'Google Ads', value: 30, color: '#A78BFA' },
  { name: 'Orgânico', value: 15, color: '#C4B5FD' },
  { name: 'Direto', value: 10, color: '#DDD6FE' },
]

const kpiCards = [
  {
    title: 'CAC Médio',
    value: 'R$ 135,71',
    change: '-18%',
    positive: true,
    icon: <Users className="w-6 h-6" />,
    description: 'Custo de Aquisição por Cliente'
  },
  {
    title: 'LTV',
    value: 'R$ 12.400',
    change: '+32%',
    positive: true,
    icon: <DollarSign className="w-6 h-6" />,
    description: 'Lifetime Value médio'
  },
  {
    title: 'Taxa de Conversão',
    value: '3,8%',
    change: '+12%',
    positive: true,
    icon: <Target className="w-6 h-6" />,
    description: 'Lead para Cliente'
  },
  {
    title: 'ROAS Atual',
    value: '7,0x',
    change: '+133%',
    positive: true,
    icon: <TrendingUp className="w-6 h-6" />,
    description: 'Return on Ad Spend'
  },
]

export default function AnalyticsPage() {
  return (
    <div className="min-h-screen bg-dark flex">
      <Sidebar />

      <main className="flex-1 p-8 ml-64">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8 flex items-center justify-between"
        >
          <div>
            <h1 className="text-4xl font-bold gradient-text mb-2">
              Analytics Avançado
            </h1>
            <p className="text-gray-400">
              Métricas reais de negócio - CAC, LTV, ROI e lucro líquido
            </p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 px-6 py-3 bg-purple rounded-xl hover:bg-purple-light transition-colors"
          >
            <Download className="w-5 h-5" />
            Exportar Relatório
          </motion.button>
        </motion.div>

        {/* KPI Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {kpiCards.map((kpi, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="glass-effect-strong rounded-2xl p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-xl bg-purple/20 text-purple-light">
                  {kpi.icon}
                </div>
                <span className={`text-sm font-semibold ${kpi.positive ? 'text-green-400' : 'text-red-400'}`}>
                  {kpi.change}
                </span>
              </div>
              <h3 className="text-gray-400 text-sm mb-1">{kpi.title}</h3>
              <p className="text-3xl font-bold mb-1">{kpi.value}</p>
              <p className="text-xs text-gray-500">{kpi.description}</p>
            </motion.div>
          ))}
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Revenue vs Investment */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="glass-effect-strong rounded-2xl p-6"
          >
            <h2 className="text-2xl font-bold mb-6">Receita vs Investimento</h2>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1F1F29" />
                  <XAxis dataKey="mes" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#131318',
                      border: '1px solid #1F1F29',
                      borderRadius: '8px',
                    }}
                  />
                  <Legend />
                  <Bar dataKey="investimento" fill="#8B5CF6" name="Investimento" />
                  <Bar dataKey="receita" fill="#10B981" name="Receita" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* ROAS Evolution */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="glass-effect-strong rounded-2xl p-6"
          >
            <h2 className="text-2xl font-bold mb-6">Evolução do ROAS</h2>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={roiData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1F1F29" />
                  <XAxis dataKey="mes" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#131318',
                      border: '1px solid #1F1F29',
                      borderRadius: '8px',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="roas"
                    stroke="#8B5CF6"
                    strokeWidth={3}
                    name="ROAS"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        </div>

        {/* Performance Details & Channel Distribution */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Leads & Conversions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className="lg:col-span-2 glass-effect-strong rounded-2xl p-6"
          >
            <h2 className="text-2xl font-bold mb-6">Leads e Conversões</h2>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1F1F29" />
                  <XAxis dataKey="mes" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#131318',
                      border: '1px solid #1F1F29',
                      borderRadius: '8px',
                    }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="leads"
                    stroke="#A78BFA"
                    strokeWidth={3}
                    name="Leads"
                  />
                  <Line
                    type="monotone"
                    dataKey="conversoes"
                    stroke="#10B981"
                    strokeWidth={3}
                    name="Conversões"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          {/* Channel Distribution */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="glass-effect-strong rounded-2xl p-6"
          >
            <h2 className="text-2xl font-bold mb-6">Canais</h2>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={channelData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {channelData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-2 mt-4">
              {channelData.map((channel, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: channel.color }}
                    />
                    <span>{channel.name}</span>
                  </div>
                  <span className="font-semibold">{channel.value}%</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  )
}
