'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import DashboardLoader from '@/components/DashboardLoader'

export default function HomePage() {
  const router = useRouter()

  return <DashboardLoader onComplete={() => router.push('/dashboard')} />
}
