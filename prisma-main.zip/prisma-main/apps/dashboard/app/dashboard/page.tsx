"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import MainDashboard from "@/components/MainDashboard";

export default function DashboardPage() {
  const router = useRouter();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Verificar autenticação
    const token = localStorage.getItem("auth_token");
    const user = localStorage.getItem("user");

    console.log("🔍 Verificando autenticação no dashboard...");
    console.log("Token:", token ? "✅ Encontrado" : "❌ Não encontrado");
    console.log("User:", user ? "✅ Encontrado" : "❌ Não encontrado");

    if (!token || !user) {
      console.log("❌ Não autenticado, redirecionando para /login");
      router.push("/login");
    } else {
      console.log("✅ Autenticado, carregando dashboard");
      setIsAuthenticated(true);
    }

    setIsLoading(false);
  }, [router]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-dark flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple mx-auto mb-4"></div>
          <p className="text-gray-400">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return <MainDashboard />;
}
