"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  useMutation,
  gql,
  ApolloClient,
  InMemoryCache,
  ApolloProvider,
  createHttpLink,
} from "@apollo/client";
import { motion } from "framer-motion";

const LOGIN_MUTATION = gql`
  mutation Login($email: String!, $password: String!) {
    login(email: $email, password: $password) {
      token
      user {
        id
        name
        email
        role
      }
    }
  }
`;

function LoginForm() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  // Redirecionar se já estiver autenticado
  useEffect(() => {
    const token = localStorage.getItem("auth_token");
    if (token) {
      console.log("✅ Já autenticado, redirecionando para /dashboard");
      router.push("/dashboard");
    }
  }, [router]);

  const [login, { loading }] = useMutation(LOGIN_MUTATION, {
    onCompleted: (data) => {
      console.log("✅ Login successful!", data);
      console.log("🔐 Token:", data.login.token);
      console.log("👤 User:", data.login.user);

      try {
        // Salvar no localStorage
        localStorage.setItem("auth_token", data.login.token);
        localStorage.setItem("user", JSON.stringify(data.login.user));
        console.log("✅ Token saved to localStorage");

        // IMPORTANTE: Salvar também nos cookies para o middleware
        document.cookie = `auth_token=${data.login.token}; path=/; max-age=${
          7 * 24 * 60 * 60
        }`; // 7 dias
        console.log("✅ Token saved to cookies");

        // Verificar se foi salvo
        const savedToken = localStorage.getItem("auth_token");
        console.log(
          "🔍 Token verificado no localStorage:",
          savedToken ? "✅ Encontrado" : "❌ Não encontrado"
        );

        // Pequeno delay para garantir que o localStorage foi atualizado
        setTimeout(() => {
          console.log("🚀 Redirecting to /dashboard...");
          router.push("/dashboard");
        }, 100);
      } catch (error) {
        console.error("❌ Error in onCompleted:", error);
      }
    },
    onError: (err) => {
      console.error("❌ Login error:", err);
      setError("Email ou senha inválidos");
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    login({ variables: { email, password } });
  };

  return (
    <div className="min-h-screen bg-dark flex items-center justify-center overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 opacity-20">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `
            linear-gradient(rgba(135, 89, 242, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(135, 89, 242, 0.1) 1px, transparent 1px)
          `,
            backgroundSize: "50px 50px",
          }}
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative z-10 w-full max-w-md px-6"
      >
        <form
          onSubmit={handleSubmit}
          className="glass-effect-strong p-8 rounded-2xl"
        >
          {/* Logo */}
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-center mb-8"
          >
            <h1 className="text-4xl font-bold gradient-text mb-2">PRISMA</h1>
            <p className="text-gray-400 text-sm">Marketing Intelligence</p>
          </motion.div>

          {/* Error message */}
          {error && (
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-red-500/20 border border-red-500/50 text-red-400 p-3 rounded-lg mb-4 text-sm"
            >
              {error}
            </motion.div>
          )}

          {/* Email input */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Email
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="seu@email.com"
              required
              className="w-full px-4 py-3 bg-dark-border rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple transition-all"
            />
          </div>

          {/* Password input */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Senha
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              className="w-full px-4 py-3 bg-dark-border rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-purple transition-all"
            />
          </div>

          {/* Submit button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-purple rounded-xl hover:bg-purple-light transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? "Entrando..." : "Entrar"}
          </motion.button>

          {/* Demo credentials hint */}
          <div className="mt-6 p-4 bg-dark-border/50 rounded-lg">
            <p className="text-xs text-gray-400 mb-2">Credenciais de demo:</p>
            <p className="text-xs text-gray-300">
              Email: contato@empresademo.com.br
            </p>
            <p className="text-xs text-gray-300">Senha: demo123</p>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

export default function LoginPage() {
  // Create a separate Apollo client for login page (no auth needed)
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";
  const graphqlUri = `${apiUrl}/graphql`;

  console.log("🔍 GraphQL URI:", graphqlUri);
  console.log("🔍 NEXT_PUBLIC_API_URL:", process.env.NEXT_PUBLIC_API_URL);

  const httpLink = createHttpLink({
    uri: graphqlUri,
  });

  const client = new ApolloClient({
    link: httpLink,
    cache: new InMemoryCache(),
  });

  return (
    <ApolloProvider client={client}>
      <LoginForm />
    </ApolloProvider>
  );
}
