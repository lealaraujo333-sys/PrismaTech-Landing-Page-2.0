'use client'

import { motion } from 'framer-motion'
import Sidebar from '@/components/Sidebar'
import { Bot, MessageSquare, TrendingUp, Users, Play, Pause, Settings as SettingsIcon, Activity } from 'lucide-react'

// Mock data baseado no prisma.md - AI Agents
const agents = [
  {
    id: 1,
    name: 'Agente WhatsApp - Recepção',
    type: 'WHATSAPP_RECEPTION',
    status: 'ACTIVE',
    description: 'Recepciona, qualifica e direciona leads do WhatsApp',
    stats: {
      conversas: 1247,
      leadsQualificados: 892,
      taxaQualificacao: '71%',
    },
    lastRun: 'há 2 min',
    icon: <MessageSquare className="w-6 h-6" />,
    color: 'purple'
  },
  {
    id: 2,
    name: 'Agente Closer - Vendas',
    type: 'SALES_CLOSER',
    status: 'ACTIVE',
    description: 'Consultor que personaliza propostas e fecha negócios',
    stats: {
      propostas: 234,
      fechamentos: 67,
      taxaConversao: '28,6%',
    },
    lastRun: 'há 5 min',
    icon: <TrendingUp className="w-6 h-6" />,
    color: 'green'
  },
  {
    id: 3,
    name: 'Monitor CPC',
    type: 'CPC_MONITOR',
    status: 'ACTIVE',
    description: 'Detecta picos de CPC e gera alertas automáticos',
    stats: {
      verificacoes: 8640,
      alertasGerados: 12,
      economia: 'R$ 3.240',
    },
    lastRun: 'há 1 min',
    icon: <Activity className="w-6 h-6" />,
    color: 'orange'
  },
  {
    id: 4,
    name: 'Monitor CTR',
    type: 'CTR_MONITOR',
    status: 'ACTIVE',
    description: 'Identifica quedas de CTR e sugere otimizações',
    stats: {
      verificacoes: 8640,
      alertasGerados: 8,
      melhorias: '15 sugestões',
    },
    lastRun: 'há 3 min',
    icon: <Activity className="w-6 h-6" />,
    color: 'blue'
  },
  {
    id: 5,
    name: 'Agente Coordenador',
    type: 'COORDINATOR',
    status: 'ACTIVE',
    description: 'Orquestra todos os agentes e faz load balancing',
    stats: {
      tarefas: 3421,
      distribuidas: 3421,
      eficiencia: '99,7%',
    },
    lastRun: 'há 1 min',
    icon: <Bot className="w-6 h-6" />,
    color: 'purple'
  },
  {
    id: 6,
    name: 'Monitor de Conversão',
    type: 'CONVERSION_MONITOR',
    status: 'PAUSED',
    description: 'Analisa taxa de conversão e identifica gargalos',
    stats: {
      verificacoes: 4320,
      alertasGerados: 5,
      otimizacoes: '8 aplicadas',
    },
    lastRun: 'há 2 horas',
    icon: <Users className="w-6 h-6" />,
    color: 'yellow'
  },
]

const recentActivity = [
  {
    agent: 'Agente WhatsApp - Recepção',
    action: 'Qualificou 3 novos leads',
    time: 'há 2 min',
    status: 'success'
  },
  {
    agent: 'Monitor CPC',
    action: 'Alerta: CPC aumentou 1.8x na campanha "Black Friday"',
    time: 'há 15 min',
    status: 'warning'
  },
  {
    agent: 'Agente Closer',
    action: 'Fechou 1 venda - R$ 3.800',
    time: 'há 23 min',
    status: 'success'
  },
  {
    agent: 'Monitor CTR',
    action: 'Sugeriu otimização para 2 anúncios',
    time: 'há 1 hora',
    status: 'info'
  },
  {
    agent: 'Agente Coordenador',
    action: 'Distribuiu 45 tarefas entre os agentes',
    time: 'há 2 horas',
    status: 'info'
  },
]

const statusColors = {
  ACTIVE: 'text-green-400 bg-green-400/20',
  PAUSED: 'text-yellow-400 bg-yellow-400/20',
  ERROR: 'text-red-400 bg-red-400/20',
}

const activityStatusColors = {
  success: 'bg-green-400/20 text-green-400',
  warning: 'bg-orange-400/20 text-orange-400',
  info: 'bg-blue-400/20 text-blue-400',
  error: 'bg-red-400/20 text-red-400',
}

export default function AgentsPage() {
  return (
    <div className="min-h-screen bg-dark flex">
      <Sidebar />

      <main className="flex-1 p-8 ml-64">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold gradient-text mb-2">
            Agentes de IA
          </h1>
          <p className="text-gray-400">
            Sistema modular de agentes trabalhando 24/7 para otimizar suas campanhas
          </p>
        </motion.div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="glass-effect-strong rounded-2xl p-6"
          >
            <p className="text-gray-400 text-sm mb-2">Agentes Ativos</p>
            <p className="text-3xl font-bold">5 / 6</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="glass-effect-strong rounded-2xl p-6"
          >
            <p className="text-gray-400 text-sm mb-2">Tarefas Hoje</p>
            <p className="text-3xl font-bold">3.421</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="glass-effect-strong rounded-2xl p-6"
          >
            <p className="text-gray-400 text-sm mb-2">Leads Qualificados</p>
            <p className="text-3xl font-bold">892</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="glass-effect-strong rounded-2xl p-6"
          >
            <p className="text-gray-400 text-sm mb-2">Economia Gerada</p>
            <p className="text-3xl font-bold text-green-400">R$ 3.240</p>
          </motion.div>
        </div>

        {/* Agents Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {agents.map((agent, index) => (
            <motion.div
              key={agent.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.5 + index * 0.1 }}
              className="glass-effect-strong rounded-2xl p-6 hover:border-purple/50 transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-xl bg-${agent.color}/20 text-${agent.color}-light`}>
                    {agent.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">{agent.name}</h3>
                    <p className="text-sm text-gray-400">{agent.type}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${statusColors[agent.status as keyof typeof statusColors]}`}>
                    {agent.status === 'ACTIVE' ? 'Ativo' : 'Pausado'}
                  </span>
                </div>
              </div>

              <p className="text-gray-400 mb-4">{agent.description}</p>

              <div className="grid grid-cols-3 gap-4 mb-4">
                {Object.entries(agent.stats).map(([key, value]) => (
                  <div key={key}>
                    <p className="text-xs text-gray-500 mb-1">
                      {key === 'conversas' ? 'Conversas' :
                       key === 'leadsQualificados' ? 'Qualificados' :
                       key === 'taxaQualificacao' ? 'Taxa' :
                       key === 'propostas' ? 'Propostas' :
                       key === 'fechamentos' ? 'Fechamentos' :
                       key === 'taxaConversao' ? 'Conversão' :
                       key === 'verificacoes' ? 'Verificações' :
                       key === 'alertasGerados' ? 'Alertas' :
                       key === 'economia' ? 'Economia' :
                       key === 'melhorias' ? 'Melhorias' :
                       key === 'tarefas' ? 'Tarefas' :
                       key === 'distribuidas' ? 'Distribuídas' :
                       key === 'eficiencia' ? 'Eficiência' :
                       key === 'otimizacoes' ? 'Otimizações' : key}
                    </p>
                    <p className="text-lg font-semibold">{value}</p>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-dark-border">
                <span className="text-xs text-gray-500">Última execução: {agent.lastRun}</span>
                <div className="flex gap-2">
                  <button className="p-2 rounded-lg hover:bg-dark-border transition-colors">
                    {agent.status === 'ACTIVE' ? (
                      <Pause className="w-4 h-4" />
                    ) : (
                      <Play className="w-4 h-4" />
                    )}
                  </button>
                  <button className="p-2 rounded-lg hover:bg-dark-border transition-colors">
                    <SettingsIcon className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 1.1 }}
          className="glass-effect-strong rounded-2xl p-6"
        >
          <h2 className="text-2xl font-bold mb-6">Atividade Recente</h2>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div
                key={index}
                className="flex items-start gap-4 p-4 rounded-xl bg-dark-border/30 hover:bg-dark-border/50 transition-colors"
              >
                <div className={`w-2 h-2 rounded-full mt-2 ${activityStatusColors[activity.status as keyof typeof activityStatusColors]}`} />
                <div className="flex-1">
                  <p className="font-medium mb-1">{activity.agent}</p>
                  <p className="text-sm text-gray-400">{activity.action}</p>
                </div>
                <span className="text-xs text-gray-500">{activity.time}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </main>
    </div>
  )
}
