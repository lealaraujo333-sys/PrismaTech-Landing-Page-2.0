'use client'

import { motion } from 'framer-motion'
import Sidebar from '@/components/Sidebar'
import { User, Bell, Key, CreditCard, Zap, Globe, Shield, Save, CheckCircle, Plus } from 'lucide-react'
import { useState } from 'react'

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState('account')
  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 3000)
  }

  const tabs = [
    { id: 'account', label: 'Conta', icon: <User className="w-5 h-5" /> },
    { id: 'notifications', label: 'Notificações', icon: <Bell className="w-5 h-5" /> },
    { id: 'integrations', label: 'Integrações', icon: <Zap className="w-5 h-5" /> },
    { id: 'billing', label: 'Faturamento', icon: <CreditCard className="w-5 h-5" /> },
    { id: 'security', label: 'Segurança', icon: <Shield className="w-5 h-5" /> },
    { id: 'api', label: 'API', icon: <Key className="w-5 h-5" /> },
  ]

  return (
    <div className="min-h-screen bg-dark flex">
      <Sidebar />

      <main className="flex-1 p-8 ml-64">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold gradient-text mb-2">
            Configurações
          </h1>
          <p className="text-gray-400">
            Gerencie sua conta, integrações e preferências
          </p>
        </motion.div>

        <div className="flex gap-8">
          {/* Sidebar Tabs */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="w-64 space-y-2"
          >
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                  activeTab === tab.id
                    ? 'bg-purple text-white'
                    : 'text-gray-400 hover:bg-dark-border hover:text-white'
                }`}
              >
                {tab.icon}
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </motion.div>

          {/* Content Area */}
          <div className="flex-1">
            {/* Account Settings */}
            {activeTab === 'account' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="glass-effect-strong rounded-2xl p-8"
              >
                <h2 className="text-2xl font-bold mb-6">Informações da Conta</h2>

                <div className="space-y-6">
                  <div className="flex items-center gap-6 pb-6 border-b border-dark-border">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-purple to-purple-light flex items-center justify-center text-2xl font-bold">
                      AC
                    </div>
                    <div>
                      <button className="px-4 py-2 bg-purple rounded-lg hover:bg-purple-light transition-colors text-sm">
                        Alterar Foto
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-2">Nome</label>
                      <input
                        type="text"
                        defaultValue="Admin"
                        className="w-full px-4 py-3 bg-dark-border rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-2">Sobrenome</label>
                      <input
                        type="text"
                        defaultValue="Cliente"
                        className="w-full px-4 py-3 bg-dark-border rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Email</label>
                    <input
                      type="email"
                      defaultValue="admin@empresa.com"
                      className="w-full px-4 py-3 bg-dark-border rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Empresa</label>
                    <input
                      type="text"
                      defaultValue="Empresa Exemplo Ltda"
                      className="w-full px-4 py-3 bg-dark-border rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Fuso Horário</label>
                    <select className="w-full px-4 py-3 bg-dark-border rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple">
                      <option>America/Sao_Paulo (GMT-3)</option>
                      <option>America/New_York (GMT-5)</option>
                      <option>Europe/London (GMT+0)</option>
                    </select>
                  </div>
                </div>

                <button
                  onClick={handleSave}
                  className="mt-8 flex items-center gap-2 px-6 py-3 bg-purple rounded-xl hover:bg-purple-light transition-colors"
                >
                  <Save className="w-5 h-5" />
                  Salvar Alterações
                </button>
              </motion.div>
            )}

            {/* Notifications Settings */}
            {activeTab === 'notifications' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="glass-effect-strong rounded-2xl p-8"
              >
                <h2 className="text-2xl font-bold mb-6">Preferências de Notificação</h2>

                <div className="space-y-6">
                  <div className="flex items-center justify-between py-4 border-b border-dark-border">
                    <div>
                      <h3 className="font-semibold mb-1">Alertas de IA</h3>
                      <p className="text-sm text-gray-400">Notificações quando agentes detectarem anomalias</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked className="sr-only peer" />
                      <div className="w-11 h-6 bg-dark-border peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between py-4 border-b border-dark-border">
                    <div>
                      <h3 className="font-semibold mb-1">Novos Leads</h3>
                      <p className="text-sm text-gray-400">Notificar sobre novos leads qualificados</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked className="sr-only peer" />
                      <div className="w-11 h-6 bg-dark-border peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between py-4 border-b border-dark-border">
                    <div>
                      <h3 className="font-semibold mb-1">Relatórios Semanais</h3>
                      <p className="text-sm text-gray-400">Resumo semanal de performance por email</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked className="sr-only peer" />
                      <div className="w-11 h-6 bg-dark-border peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between py-4 border-b border-dark-border">
                    <div>
                      <h3 className="font-semibold mb-1">Mudanças de Campanha</h3>
                      <p className="text-sm text-gray-400">Alertas sobre alterações nas campanhas</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" />
                      <div className="w-11 h-6 bg-dark-border peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple"></div>
                    </label>
                  </div>

                  <div className="flex items-center justify-between py-4">
                    <div>
                      <h3 className="font-semibold mb-1">Notificações Push</h3>
                      <p className="text-sm text-gray-400">Receber notificações push no navegador</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" />
                      <div className="w-11 h-6 bg-dark-border peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple"></div>
                    </label>
                  </div>
                </div>

                <button
                  onClick={handleSave}
                  className="mt-8 flex items-center gap-2 px-6 py-3 bg-purple rounded-xl hover:bg-purple-light transition-colors"
                >
                  <Save className="w-5 h-5" />
                  Salvar Preferências
                </button>
              </motion.div>
            )}

            {/* Integrations */}
            {activeTab === 'integrations' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="glass-effect-strong rounded-2xl p-8"
              >
                <h2 className="text-2xl font-bold mb-6">Integrações</h2>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-dark-border/30 rounded-xl">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center text-2xl">
                        f
                      </div>
                      <div>
                        <h3 className="font-semibold">Facebook Ads</h3>
                        <p className="text-sm text-gray-400">Conectado</p>
                      </div>
                    </div>
                    <button className="px-4 py-2 bg-green-500/20 text-green-400 rounded-lg text-sm">
                      Conectado
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-dark-border/30 rounded-xl">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-red-500 rounded-lg flex items-center justify-center text-2xl font-bold">
                        G
                      </div>
                      <div>
                        <h3 className="font-semibold">Google Ads</h3>
                        <p className="text-sm text-gray-400">Conectado</p>
                      </div>
                    </div>
                    <button className="px-4 py-2 bg-green-500/20 text-green-400 rounded-lg text-sm">
                      Conectado
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-dark-border/30 rounded-xl">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 rounded-lg flex items-center justify-center text-2xl">
                        📷
                      </div>
                      <div>
                        <h3 className="font-semibold">Instagram</h3>
                        <p className="text-sm text-gray-400">Não conectado</p>
                      </div>
                    </div>
                    <button className="px-4 py-2 bg-purple rounded-lg hover:bg-purple-light transition-colors text-sm">
                      Conectar
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-dark-border/30 rounded-xl">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center text-2xl">
                        💬
                      </div>
                      <div>
                        <h3 className="font-semibold">WhatsApp Business</h3>
                        <p className="text-sm text-gray-400">Conectado</p>
                      </div>
                    </div>
                    <button className="px-4 py-2 bg-green-500/20 text-green-400 rounded-lg text-sm">
                      Conectado
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Billing */}
            {activeTab === 'billing' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="glass-effect-strong rounded-2xl p-8"
              >
                <h2 className="text-2xl font-bold mb-6">Faturamento</h2>

                <div className="space-y-6">
                  <div className="p-6 bg-gradient-to-br from-purple/20 to-purple-light/20 rounded-xl border border-purple/30">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold">Plano Enterprise</h3>
                        <p className="text-gray-400">Renovação automática mensal</p>
                      </div>
                      <div className="text-right">
                        <p className="text-3xl font-bold">R$ 3.800</p>
                        <p className="text-sm text-gray-400">/mês</p>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <button className="px-4 py-2 bg-purple rounded-lg hover:bg-purple-light transition-colors text-sm">
                        Atualizar Plano
                      </button>
                      <button className="px-4 py-2 bg-dark-border rounded-lg hover:bg-dark-border/50 transition-colors text-sm">
                        Cancelar Assinatura
                      </button>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-4">Método de Pagamento</h3>
                    <div className="flex items-center justify-between p-4 bg-dark-border/30 rounded-xl">
                      <div className="flex items-center gap-4">
                        <CreditCard className="w-8 h-8 text-purple-400" />
                        <div>
                          <p className="font-medium">•••• •••• •••• 4242</p>
                          <p className="text-sm text-gray-400">Expira em 12/2025</p>
                        </div>
                      </div>
                      <button className="px-4 py-2 bg-dark-border rounded-lg hover:bg-dark-border/50 transition-colors text-sm">
                        Alterar
                      </button>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-4">Histórico de Faturas</h3>
                    <div className="space-y-2">
                      {[
                        { date: 'Jun 2024', amount: 'R$ 3.800', status: 'Pago' },
                        { date: 'Mai 2024', amount: 'R$ 3.800', status: 'Pago' },
                        { date: 'Abr 2024', amount: 'R$ 3.800', status: 'Pago' },
                      ].map((invoice, i) => (
                        <div key={i} className="flex items-center justify-between p-4 bg-dark-border/30 rounded-xl">
                          <div>
                            <p className="font-medium">{invoice.date}</p>
                            <p className="text-sm text-gray-400">{invoice.status}</p>
                          </div>
                          <div className="flex items-center gap-4">
                            <p className="font-semibold">{invoice.amount}</p>
                            <button className="text-purple-400 hover:text-purple-light text-sm">
                              Download
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* Security */}
            {activeTab === 'security' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="glass-effect-strong rounded-2xl p-8"
              >
                <h2 className="text-2xl font-bold mb-6">Segurança</h2>

                <div className="space-y-6">
                  <div>
                    <h3 className="font-semibold mb-4">Alterar Senha</h3>
                    <div className="space-y-4">
                      <input
                        type="password"
                        placeholder="Senha atual"
                        className="w-full px-4 py-3 bg-dark-border rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple"
                      />
                      <input
                        type="password"
                        placeholder="Nova senha"
                        className="w-full px-4 py-3 bg-dark-border rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple"
                      />
                      <input
                        type="password"
                        placeholder="Confirmar nova senha"
                        className="w-full px-4 py-3 bg-dark-border rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple"
                      />
                      <button className="px-6 py-3 bg-purple rounded-xl hover:bg-purple-light transition-colors">
                        Alterar Senha
                      </button>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-dark-border">
                    <h3 className="font-semibold mb-4">Autenticação de Dois Fatores</h3>
                    <div className="flex items-center justify-between p-4 bg-dark-border/30 rounded-xl">
                      <div>
                        <p className="font-medium mb-1">2FA Desativado</p>
                        <p className="text-sm text-gray-400">Adicione uma camada extra de segurança</p>
                      </div>
                      <button className="px-4 py-2 bg-purple rounded-lg hover:bg-purple-light transition-colors text-sm">
                        Ativar 2FA
                      </button>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-dark-border">
                    <h3 className="font-semibold mb-4">Sessões Ativas</h3>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between p-4 bg-dark-border/30 rounded-xl">
                        <div>
                          <p className="font-medium">MacBook Pro - São Paulo, BR</p>
                          <p className="text-sm text-gray-400">Sessão atual • Último acesso agora</p>
                        </div>
                        <span className="text-green-400 text-sm">Ativo</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {/* API */}
            {activeTab === 'api' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="glass-effect-strong rounded-2xl p-8"
              >
                <h2 className="text-2xl font-bold mb-6">Chaves de API</h2>

                <div className="space-y-6">
                  <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-xl">
                    <p className="text-sm text-blue-400">
                      <strong>Atenção:</strong> Mantenha suas chaves de API seguras. Não compartilhe em repositórios públicos.
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-4">Chave de Produção</h3>
                    <div className="flex items-center gap-3">
                      <input
                        type="text"
                        value="pk_live_xxxxxxxxxxxxxxxxxxxxxxxx"
                        readOnly
                        className="flex-1 px-4 py-3 bg-dark-border rounded-xl text-white focus:outline-none"
                      />
                      <button className="px-4 py-3 bg-purple rounded-xl hover:bg-purple-light transition-colors">
                        Copiar
                      </button>
                      <button className="px-4 py-3 bg-dark-border rounded-xl hover:bg-dark-border/50 transition-colors">
                        Regenerar
                      </button>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-4">Chave de Teste</h3>
                    <div className="flex items-center gap-3">
                      <input
                        type="text"
                        value="pk_test_xxxxxxxxxxxxxxxxxxxxxxxx"
                        readOnly
                        className="flex-1 px-4 py-3 bg-dark-border rounded-xl text-white focus:outline-none"
                      />
                      <button className="px-4 py-3 bg-purple rounded-xl hover:bg-purple-light transition-colors">
                        Copiar
                      </button>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-dark-border">
                    <h3 className="font-semibold mb-4">Webhooks</h3>
                    <button className="flex items-center gap-2 px-6 py-3 bg-purple rounded-xl hover:bg-purple-light transition-colors">
                      <Plus className="w-5 h-5" />
                      Adicionar Webhook
                    </button>
                  </div>

                  <div className="pt-6 border-t border-dark-border">
                    <h3 className="font-semibold mb-2">Documentação da API</h3>
                    <p className="text-sm text-gray-400 mb-4">
                      Acesse a documentação completa para integrar a Prisma em suas aplicações
                    </p>
                    <button className="flex items-center gap-2 px-6 py-3 bg-dark-border rounded-xl hover:bg-dark-border/50 transition-colors">
                      <Globe className="w-5 h-5" />
                      Ver Documentação
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        </div>

        {/* Save Success Toast */}
        {saved && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="fixed bottom-8 right-8 flex items-center gap-3 px-6 py-4 bg-green-500 text-white rounded-xl shadow-lg"
          >
            <CheckCircle className="w-5 h-5" />
            <span className="font-medium">Configurações salvas com sucesso!</span>
          </motion.div>
        )}
      </main>
    </div>
  )
}
