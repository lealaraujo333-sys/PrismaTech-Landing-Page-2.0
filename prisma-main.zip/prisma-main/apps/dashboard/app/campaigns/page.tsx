'use client'

import { motion } from 'framer-motion'
import Sidebar from '@/components/Sidebar'
import { Target, TrendingUp, DollarSign, MousePointer, Eye, Activity, Play, Pause, Edit, Trash2, Plus } from 'lucide-react'
import { useState } from 'react'

// Mock data baseado no prisma.md - Campaigns & Ads
const campaigns = [
  {
    id: 1,
    name: 'Black Friday 2024',
    platform: 'Facebook Ads',
    status: 'ACTIVE',
    budget: 3800,
    spent: 2340,
    impressions: 145000,
    clicks: 3420,
    conversions: 28,
    revenue: 26600,
    ctr: 2.36,
    cpc: 0.68,
    roas: 11.37,
    startDate: '2024-06-01',
    endDate: '2024-06-30',
    ads: 12,
    alerts: [
      { type: 'warning', message: 'CPC aumentou 1.8x nas últimas 24h' }
    ]
  },
  {
    id: 2,
    name: 'Lançamento Produto',
    platform: 'Google Ads',
    status: 'ACTIVE',
    budget: 2500,
    spent: 1890,
    impressions: 89000,
    clicks: 2140,
    conversions: 18,
    revenue: 18900,
    ctr: 2.40,
    cpc: 0.88,
    roas: 10.00,
    startDate: '2024-06-05',
    endDate: '2024-06-25',
    ads: 8,
    alerts: []
  },
  {
    id: 3,
    name: 'Retargeting Q2',
    platform: 'Facebook Ads',
    status: 'ACTIVE',
    budget: 1500,
    spent: 1200,
    impressions: 67000,
    clicks: 1680,
    conversions: 14,
    revenue: 13300,
    ctr: 2.51,
    cpc: 0.71,
    roas: 11.08,
    startDate: '2024-04-01',
    endDate: '2024-06-30',
    ads: 6,
    alerts: [
      { type: 'info', message: 'CTR 15% acima da média do setor' }
    ]
  },
  {
    id: 4,
    name: 'Lead Generation',
    platform: 'Instagram Ads',
    status: 'PAUSED',
    budget: 2000,
    spent: 980,
    impressions: 52000,
    clicks: 1240,
    conversions: 8,
    revenue: 8200,
    ctr: 2.38,
    cpc: 0.79,
    roas: 8.37,
    startDate: '2024-05-15',
    endDate: '2024-06-15',
    ads: 5,
    alerts: [
      { type: 'error', message: 'Taxa de conversão abaixo da meta' }
    ]
  },
  {
    id: 5,
    name: 'Awareness Marca',
    platform: 'Google Ads',
    status: 'ACTIVE',
    budget: 3000,
    spent: 2450,
    impressions: 198000,
    clicks: 4560,
    conversions: 24,
    revenue: 22800,
    ctr: 2.30,
    cpc: 0.54,
    roas: 9.31,
    startDate: '2024-05-01',
    endDate: '2024-06-30',
    ads: 15,
    alerts: []
  },
]

const statusColors = {
  ACTIVE: 'bg-green-400/20 text-green-400',
  PAUSED: 'bg-yellow-400/20 text-yellow-400',
  ENDED: 'bg-gray-400/20 text-gray-400',
}

const statusLabels = {
  ACTIVE: 'Ativa',
  PAUSED: 'Pausada',
  ENDED: 'Finalizada',
}

const alertColors = {
  warning: 'bg-orange-400/20 text-orange-400 border-orange-400/50',
  error: 'bg-red-400/20 text-red-400 border-red-400/50',
  info: 'bg-blue-400/20 text-blue-400 border-blue-400/50',
}

export default function CampaignsPage() {
  const [selectedPlatform, setSelectedPlatform] = useState<string>('all')

  const filteredCampaigns = campaigns.filter(campaign => {
    return selectedPlatform === 'all' || campaign.platform === selectedPlatform
  })

  const stats = {
    totalBudget: campaigns.reduce((acc, c) => acc + c.budget, 0),
    totalSpent: campaigns.reduce((acc, c) => acc + c.spent, 0),
    totalRevenue: campaigns.reduce((acc, c) => acc + c.revenue, 0),
    avgRoas: (campaigns.reduce((acc, c) => acc + c.roas, 0) / campaigns.length).toFixed(2),
  }

  return (
    <div className="min-h-screen bg-dark flex">
      <Sidebar />

      <main className="flex-1 p-8 ml-64">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8 flex items-center justify-between"
        >
          <div>
            <h1 className="text-4xl font-bold gradient-text mb-2">
              Campanhas Publicitárias
            </h1>
            <p className="text-gray-400">
              Gestão completa de campanhas multi-plataforma
            </p>
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 px-6 py-3 bg-purple rounded-xl hover:bg-purple-light transition-colors"
          >
            <Plus className="w-5 h-5" />
            Nova Campanha
          </motion.button>
        </motion.div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="glass-effect-strong rounded-2xl p-6"
          >
            <div className="flex items-center gap-3 mb-2">
              <DollarSign className="w-5 h-5 text-blue-400" />
              <p className="text-gray-400 text-sm">Orçamento Total</p>
            </div>
            <p className="text-3xl font-bold">R$ {stats.totalBudget.toLocaleString()}</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="glass-effect-strong rounded-2xl p-6"
          >
            <div className="flex items-center gap-3 mb-2">
              <Activity className="w-5 h-5 text-orange-400" />
              <p className="text-gray-400 text-sm">Investido</p>
            </div>
            <p className="text-3xl font-bold text-orange-400">R$ {stats.totalSpent.toLocaleString()}</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="glass-effect-strong rounded-2xl p-6"
          >
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <p className="text-gray-400 text-sm">Receita Gerada</p>
            </div>
            <p className="text-3xl font-bold text-green-400">R$ {stats.totalRevenue.toLocaleString()}</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="glass-effect-strong rounded-2xl p-6"
          >
            <div className="flex items-center gap-3 mb-2">
              <Target className="w-5 h-5 text-purple-400" />
              <p className="text-gray-400 text-sm">ROAS Médio</p>
            </div>
            <p className="text-3xl font-bold text-purple-400">{stats.avgRoas}x</p>
          </motion.div>
        </div>

        {/* Platform Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="glass-effect-strong rounded-2xl p-6 mb-8"
        >
          <div className="flex items-center gap-4">
            <span className="text-gray-400">Plataforma:</span>
            <select
              value={selectedPlatform}
              onChange={(e) => setSelectedPlatform(e.target.value)}
              className="px-4 py-2 bg-dark-border rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-purple"
            >
              <option value="all">Todas as Plataformas</option>
              <option value="Facebook Ads">Facebook Ads</option>
              <option value="Google Ads">Google Ads</option>
              <option value="Instagram Ads">Instagram Ads</option>
            </select>
          </div>
        </motion.div>

        {/* Campaigns Grid */}
        <div className="grid grid-cols-1 gap-6">
          {filteredCampaigns.map((campaign, index) => (
            <motion.div
              key={campaign.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
              className="glass-effect-strong rounded-2xl p-6 hover:border-purple/50 transition-all"
            >
              {/* Campaign Header */}
              <div className="flex items-start justify-between mb-6">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-2xl font-bold">{campaign.name}</h3>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${statusColors[campaign.status as keyof typeof statusColors]}`}>
                      {statusLabels[campaign.status as keyof typeof statusLabels]}
                    </span>
                  </div>
                  <p className="text-sm text-gray-400">{campaign.platform} • {campaign.ads} anúncios ativos</p>
                  <p className="text-xs text-gray-500 mt-1">{campaign.startDate} → {campaign.endDate}</p>
                </div>
                <div className="flex gap-2">
                  <button className="p-2 rounded-lg hover:bg-dark-border transition-colors">
                    {campaign.status === 'ACTIVE' ? (
                      <Pause className="w-4 h-4" />
                    ) : (
                      <Play className="w-4 h-4" />
                    )}
                  </button>
                  <button className="p-2 rounded-lg hover:bg-dark-border transition-colors">
                    <Edit className="w-4 h-4" />
                  </button>
                  <button className="p-2 rounded-lg hover:bg-dark-border hover:text-red-400 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Campaign Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4 mb-6">
                <div>
                  <p className="text-xs text-gray-500 mb-1">Orçamento</p>
                  <p className="text-lg font-semibold">R$ {campaign.budget.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Investido</p>
                  <p className="text-lg font-semibold text-orange-400">R$ {campaign.spent.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1 flex items-center gap-1">
                    <Eye className="w-3 h-3" /> Impressões
                  </p>
                  <p className="text-lg font-semibold">{(campaign.impressions / 1000).toFixed(0)}k</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1 flex items-center gap-1">
                    <MousePointer className="w-3 h-3" /> Cliques
                  </p>
                  <p className="text-lg font-semibold">{campaign.clicks.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">CTR</p>
                  <p className="text-lg font-semibold text-blue-400">{campaign.ctr}%</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">CPC</p>
                  <p className="text-lg font-semibold">R$ {campaign.cpc.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">Conversões</p>
                  <p className="text-lg font-semibold text-green-400">{campaign.conversions}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 mb-1">ROAS</p>
                  <p className="text-lg font-semibold text-purple-400">{campaign.roas.toFixed(2)}x</p>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex items-center justify-between text-xs text-gray-500 mb-2">
                  <span>Progresso do Orçamento</span>
                  <span>{((campaign.spent / campaign.budget) * 100).toFixed(0)}%</span>
                </div>
                <div className="w-full h-2 bg-dark-border rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple to-purple-light transition-all"
                    style={{ width: `${(campaign.spent / campaign.budget) * 100}%` }}
                  />
                </div>
              </div>

              {/* Alerts */}
              {campaign.alerts.length > 0 && (
                <div className="space-y-2">
                  {campaign.alerts.map((alert, i) => (
                    <div
                      key={i}
                      className={`p-3 rounded-lg border text-sm ${alertColors[alert.type as keyof typeof alertColors]}`}
                    >
                      {alert.message}
                    </div>
                  ))}
                </div>
              )}

              {/* Revenue */}
              <div className="mt-4 pt-4 border-t border-dark-border flex items-center justify-between">
                <span className="text-gray-400">Receita Gerada</span>
                <span className="text-2xl font-bold text-green-400">R$ {campaign.revenue.toLocaleString()}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </main>
    </div>
  )
}
