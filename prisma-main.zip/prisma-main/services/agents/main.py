"""
Prisma AI Agents Service
FastAPI service for AI-powered automation agents
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List
import uvicorn
from datetime import datetime

from agents.cpc_monitor import CPCMonitorAgent
from agents.ctr_monitor import CTRMonitorAgent
from agents.whatsapp_reception import WhatsAppReceptionAgent
from agents.sales_closer import SalesCloserAgent
from agents.coordinator import CoordinatorAgent
from db import get_db_connection, init_db

app = FastAPI(
    title="Prisma AI Agents",
    description="AI-powered automation agents for marketing analytics and lead management",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # TODO: Restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize agents
cpc_monitor = CPCMonitorAgent()
ctr_monitor = CTRMonitorAgent()
whatsapp_agent = WhatsAppReceptionAgent()
sales_agent = SalesCloserAgent()
coordinator = CoordinatorAgent()


# ============================================================================
# MODELS
# ============================================================================

class AgentRunRequest(BaseModel):
    agent_type: str
    client_id: str
    config: Optional[dict] = None


class AlertResponse(BaseModel):
    id: str
    client_id: str
    type: str
    severity: str
    title: str
    message: str
    metadata: dict
    created_at: datetime


class LeadQualificationRequest(BaseModel):
    lead_id: str
    message: str
    phone: str
    name: Optional[str] = None


class LeadQualificationResponse(BaseModel):
    qualified: bool
    quality_score: float
    reasoning: str
    suggested_stage: str


# ============================================================================
# ROUTES
# ============================================================================

@app.get("/")
async def root():
    return {
        "service": "Prisma AI Agents",
        "version": "1.0.0",
        "status": "operational"
    }


@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "agents": {
            "cpc_monitor": "active",
            "ctr_monitor": "active",
            "whatsapp_reception": "active",
            "sales_closer": "active",
            "coordinator": "active"
        }
    }


@app.post("/agents/run")
async def run_agent(request: AgentRunRequest, background_tasks: BackgroundTasks):
    """
    Manually trigger an agent to run
    """
    try:
        if request.agent_type == "cpc_monitor":
            background_tasks.add_task(cpc_monitor.run, request.client_id, request.config)
        elif request.agent_type == "ctr_monitor":
            background_tasks.add_task(ctr_monitor.run, request.client_id, request.config)
        elif request.agent_type == "whatsapp_reception":
            background_tasks.add_task(whatsapp_agent.run, request.client_id, request.config)
        elif request.agent_type == "sales_closer":
            background_tasks.add_task(sales_agent.run, request.client_id, request.config)
        else:
            raise HTTPException(status_code=400, detail="Invalid agent type")

        return {
            "success": True,
            "message": f"Agent {request.agent_type} started for client {request.client_id}"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/agents/cpc-monitor/check")
async def check_cpc_anomalies(client_id: str):
    """
    Check for CPC anomalies for a specific client
    """
    try:
        alerts = await cpc_monitor.check_anomalies(client_id)
        return {
            "success": True,
            "client_id": client_id,
            "alerts_created": len(alerts),
            "alerts": alerts
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/agents/whatsapp/qualify")
async def qualify_lead(request: LeadQualificationRequest):
    """
    Qualify a lead from WhatsApp message
    """
    try:
        result = await whatsapp_agent.qualify_lead(
            request.lead_id,
            request.message,
            request.phone,
            request.name
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/agents/coordinator/route")
async def route_task(task_type: str, client_id: str, metadata: dict):
    """
    Route a task to the appropriate agent via coordinator
    """
    try:
        result = await coordinator.route_task(task_type, client_id, metadata)
        return {
            "success": True,
            "routed_to": result["agent"],
            "message": result["message"]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/agents/stats")
async def get_agent_stats():
    """
    Get statistics for all agents
    """
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            name,
            type,
            status,
            run_count,
            last_run_at
        FROM agents
        ORDER BY name
    """)

    agents = []
    for row in cursor.fetchall():
        agents.append({
            "name": row[0],
            "type": row[1],
            "status": row[2],
            "run_count": row[3],
            "last_run_at": row[4].isoformat() if row[4] else None
        })

    cursor.close()
    conn.close()

    return {"agents": agents}


# ============================================================================
# STARTUP/SHUTDOWN
# ============================================================================

@app.on_event("startup")
async def startup_event():
    print("🤖 Starting Prisma AI Agents service...")
    init_db()
    print("✅ Database connection initialized")
    print("✅ All agents loaded and ready")


@app.on_event("shutdown")
async def shutdown_event():
    print("👋 Shutting down Prisma AI Agents service...")


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
