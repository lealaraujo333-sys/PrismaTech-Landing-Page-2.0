"""
Sales Closer Agent
Handles qualified leads, sends proposals, schedules meetings
"""

from typing import Dict, Optional
from datetime import datetime, timedelta
from db import get_db_connection


class SalesCloserAgent:
    def __init__(self):
        self.name = "Sales Closer"
        self.follow_up_delay_hours = 24
        self.max_follow_ups = 3

    async def run(self, client_id: str, config: Optional[Dict] = None):
        """Process qualified leads"""
        print(f"💼 {self.name} running for client {client_id}")

        conn = get_db_connection()
        cursor = conn.cursor()

        # Get qualified leads that need follow-up
        cursor.execute("""
            SELECT id, name, email, phone, stage, last_contact_at
            FROM leads
            WHERE
                client_id = %s
                AND qualified = true
                AND stage IN ('QUALIFIED', 'CONTACTED', 'PROPOSAL_SENT')
                AND stage != 'WON'
                AND stage != 'LOST'
            ORDER BY quality_score DESC
            LIMIT 20
        """, (client_id,))

        leads = cursor.fetchall()

        processed = 0
        for lead in leads:
            # Check if follow-up is due
            last_contact = lead['last_contact_at']
            if last_contact:
                time_since_contact = datetime.now() - last_contact
                if time_since_contact < timedelta(hours=self.follow_up_delay_hours):
                    continue  # Too soon to follow up

            # Process lead
            await self._process_lead(lead, cursor, conn)
            processed += 1

        conn.commit()
        cursor.close()
        conn.close()

        print(f"✅ {self.name} processed {processed} leads")
        return {"processed": processed}

    async def _process_lead(self, lead: Dict, cursor, conn):
        """Process a single lead"""
        lead_id = lead['id']
        current_stage = lead['stage']

        # Determine next action based on stage
        if current_stage == 'QUALIFIED':
            # Send initial proposal
            action = "Sent initial proposal"
            new_stage = 'PROPOSAL_SENT'
        elif current_stage == 'CONTACTED' or current_stage == 'PROPOSAL_SENT':
            # Follow up
            action = "Follow-up sent"
            new_stage = current_stage  # Keep same stage
        else:
            action = "No action"
            new_stage = current_stage

        # Update lead
        cursor.execute("""
            UPDATE leads
            SET
                stage = %s,
                last_contact_at = NOW(),
                notes = COALESCE(notes, '') || %s,
                updated_at = NOW()
            WHERE id = %s
        """, (
            new_stage,
            f"\n[{datetime.now().isoformat()}] Sales Agent: {action}",
            lead_id
        ))

        print(f"📧 Lead {lead['name']}: {action}")

        # TODO: In production, actually send email/WhatsApp message via Twilio/SendGrid
