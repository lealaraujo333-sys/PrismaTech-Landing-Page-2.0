"""
CPC Monitor Agent
Detects Cost-Per-Click anomalies using statistical analysis (z-score method)
"""

import numpy as np
from scipy import stats
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import httpx
from db import get_db_connection


class CPCMonitorAgent:
    def __init__(self):
        self.name = "CPC Monitor"
        self.threshold_multiplier = 1.6  # Alert if CPC > 1.6x baseline
        self.lookback_days = 7
        self.api_url = "http://api:4000/api/webhooks/agent-alerts"

    async def run(self, client_id: str, config: Optional[Dict] = None):
        """Main execution method"""
        print(f"🔍 {self.name} running for client {client_id}")

        if config:
            self.threshold_multiplier = config.get("threshold", self.threshold_multiplier)
            self.lookback_days = config.get("lookback_days", self.lookback_days)

        alerts = await self.check_anomalies(client_id)
        print(f"✅ {self.name} completed. Created {len(alerts)} alerts.")

        return alerts

    async def check_anomalies(self, client_id: str) -> List[Dict]:
        """
        Check for CPC anomalies using rolling window and z-score analysis
        """
        conn = get_db_connection()
        cursor = conn.cursor()

        # Get recent campaign metrics
        end_date = datetime.now()
        start_date = end_date - timedelta(days=self.lookback_days + 7)  # Extra days for baseline

        cursor.execute("""
            SELECT
                campaign_id,
                date,
                AVG(cpc) as avg_cpc,
                SUM(spend) as total_spend,
                SUM(clicks) as total_clicks
            FROM metric_records
            WHERE
                client_id = %s
                AND date >= %s
                AND date <= %s
                AND clicks > 0
            GROUP BY campaign_id, date
            ORDER BY campaign_id, date
        """, (client_id, start_date, end_date))

        records = cursor.fetchall()

        if not records:
            cursor.close()
            conn.close()
            return []

        # Group by campaign
        campaigns = {}
        for record in records:
            campaign_id = record['campaign_id']
            if campaign_id not in campaigns:
                campaigns[campaign_id] = []
            campaigns[campaign_id].append(record)

        alerts_created = []

        # Analyze each campaign
        for campaign_id, campaign_data in campaigns.items():
            alert = await self._analyze_campaign_cpc(
                client_id,
                campaign_id,
                campaign_data,
                cursor
            )
            if alert:
                alerts_created.append(alert)

        cursor.close()
        conn.close()

        return alerts_created

    async def _analyze_campaign_cpc(
        self,
        client_id: str,
        campaign_id: str,
        data: List[Dict],
        cursor
    ) -> Optional[Dict]:
        """
        Analyze CPC for a single campaign using z-score method
        """
        if len(data) < 5:
            return None  # Not enough data

        # Extract CPC values
        cpc_values = [float(d['avg_cpc']) for d in data]

        # Split into baseline (older) and recent (latest 2 days)
        baseline_cpcs = cpc_values[:-2]
        recent_cpcs = cpc_values[-2:]

        if len(baseline_cpcs) < 3:
            return None

        # Calculate baseline statistics
        baseline_mean = np.mean(baseline_cpcs)
        baseline_std = np.std(baseline_cpcs)

        if baseline_std == 0:
            return None  # No variation in baseline

        # Check recent values for anomalies
        current_cpc = recent_cpcs[-1]
        z_score = (current_cpc - baseline_mean) / baseline_std

        # Alert if z-score > 2 OR current CPC > threshold * baseline
        threshold_exceeded = current_cpc > (baseline_mean * self.threshold_multiplier)
        statistical_anomaly = z_score > 2.0

        if threshold_exceeded or statistical_anomaly:
            # Get campaign name
            cursor.execute(
                "SELECT name FROM campaigns WHERE id = %s",
                (campaign_id,)
            )
            campaign_result = cursor.fetchone()
            campaign_name = campaign_result['name'] if campaign_result else "Unknown Campaign"

            # Determine severity
            if z_score > 3.0 or current_cpc > (baseline_mean * 2.0):
                severity = "CRITICAL"
            elif z_score > 2.5 or current_cpc > (baseline_mean * 1.8):
                severity = "HIGH"
            else:
                severity = "MEDIUM"

            alert_data = {
                "clientId": client_id,
                "agentId": None,  # Will be set by API
                "type": "HIGH_CPC",
                "severity": severity,
                "title": f"CPC Alert: {campaign_name}",
                "message": (
                    f"Campaign '{campaign_name}' has a CPC of R$ {current_cpc:.2f}, "
                    f"which is {(current_cpc / baseline_mean):.1f}x above the baseline "
                    f"of R$ {baseline_mean:.2f}. Z-score: {z_score:.2f}. "
                    f"Consider reviewing targeting, ad creative, or bidding strategy."
                ),
                "metadata": {
                    "campaignId": campaign_id,
                    "campaignName": campaign_name,
                    "currentCpc": float(current_cpc),
                    "baselineCpc": float(baseline_mean),
                    "zScore": float(z_score),
                    "thresholdMultiplier": self.threshold_multiplier,
                    "analysisDate": datetime.now().isoformat(),
                }
            }

            # Send alert to API
            try:
                async with httpx.AsyncClient() as client:
                    response = await client.post(self.api_url, json=alert_data, timeout=5.0)
                    if response.status_code == 200:
                        print(f"🚨 Alert created for campaign {campaign_name}: CPC anomaly detected")
                        return alert_data
            except Exception as e:
                print(f"❌ Failed to send alert: {e}")

        return None
