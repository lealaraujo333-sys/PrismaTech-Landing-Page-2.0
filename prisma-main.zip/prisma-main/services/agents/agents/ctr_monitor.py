"""
CTR Monitor Agent
Detects Click-Through Rate drops
"""

import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import httpx
from db import get_db_connection


class CTRMonitorAgent:
    def __init__(self):
        self.name = "CTR Monitor"
        self.drop_threshold = 0.20  # Alert if CTR drops > 20%
        self.lookback_days = 7
        self.api_url = "http://api:4000/api/webhooks/agent-alerts"

    async def run(self, client_id: str, config: Optional[Dict] = None):
        """Main execution method"""
        print(f"🔍 {self.name} running for client {client_id}")

        if config:
            self.drop_threshold = config.get("threshold_drop", self.drop_threshold)
            self.lookback_days = config.get("lookback_days", self.lookback_days)

        alerts = await self.check_ctr_drops(client_id)
        print(f"✅ {self.name} completed. Created {len(alerts)} alerts.")

        return alerts

    async def check_ctr_drops(self, client_id: str) -> List[Dict]:
        """Check for CTR drops"""
        conn = get_db_connection()
        cursor = conn.cursor()

        end_date = datetime.now()
        start_date = end_date - timedelta(days=self.lookback_days + 7)

        cursor.execute("""
            SELECT
                campaign_id,
                date,
                AVG(ctr) as avg_ctr,
                SUM(impressions) as total_impressions
            FROM metric_records
            WHERE
                client_id = %s
                AND date >= %s
                AND date <= %s
                AND impressions > 100  -- Minimum threshold for meaningful CTR
            GROUP BY campaign_id, date
            ORDER BY campaign_id, date
        """, (client_id, start_date, end_date))

        records = cursor.fetchall()

        if not records:
            cursor.close()
            conn.close()
            return []

        # Group by campaign
        campaigns = {}
        for record in records:
            campaign_id = record['campaign_id']
            if campaign_id not in campaigns:
                campaigns[campaign_id] = []
            campaigns[campaign_id].append(record)

        alerts_created = []

        for campaign_id, campaign_data in campaigns.items():
            alert = await self._analyze_campaign_ctr(
                client_id,
                campaign_id,
                campaign_data,
                cursor
            )
            if alert:
                alerts_created.append(alert)

        cursor.close()
        conn.close()

        return alerts_created

    async def _analyze_campaign_ctr(
        self,
        client_id: str,
        campaign_id: str,
        data: List[Dict],
        cursor
    ) -> Optional[Dict]:
        """Analyze CTR for a single campaign"""
        if len(data) < 5:
            return None

        ctr_values = [float(d['avg_ctr']) for d in data]

        # Baseline vs recent
        baseline_ctrs = ctr_values[:-2]
        recent_ctr = ctr_values[-1]

        baseline_mean = np.mean(baseline_ctrs)

        if baseline_mean == 0:
            return None

        # Calculate percentage drop
        drop_percentage = (baseline_mean - recent_ctr) / baseline_mean

        if drop_percentage >= self.drop_threshold:
            # Get campaign name
            cursor.execute(
                "SELECT name FROM campaigns WHERE id = %s",
                (campaign_id,)
            )
            campaign_result = cursor.fetchone()
            campaign_name = campaign_result['name'] if campaign_result else "Unknown Campaign"

            severity = "HIGH" if drop_percentage >= 0.30 else "MEDIUM"

            alert_data = {
                "clientId": client_id,
                "agentId": None,
                "type": "LOW_CTR",
                "severity": severity,
                "title": f"CTR Drop Alert: {campaign_name}",
                "message": (
                    f"Campaign '{campaign_name}' CTR dropped {drop_percentage*100:.1f}% "
                    f"from {baseline_mean:.2f}% to {recent_ctr:.2f}%. "
                    f"Consider refreshing ad creatives or reviewing audience targeting."
                ),
                "metadata": {
                    "campaignId": campaign_id,
                    "campaignName": campaign_name,
                    "currentCtr": float(recent_ctr),
                    "baselineCtr": float(baseline_mean),
                    "dropPercentage": float(drop_percentage),
                    "analysisDate": datetime.now().isoformat(),
                }
            }

            try:
                async with httpx.AsyncClient() as client:
                    response = await client.post(self.api_url, json=alert_data, timeout=5.0)
                    if response.status_code == 200:
                        print(f"🚨 Alert created: CTR drop in {campaign_name}")
                        return alert_data
            except Exception as e:
                print(f"❌ Failed to send alert: {e}")

        return None
