"""
WhatsApp Reception Agent
Qualifies and filters incoming WhatsApp leads
"""

import re
from typing import Dict, Optional
from datetime import datetime
from db import get_db_connection


class WhatsAppReceptionAgent:
    def __init__(self):
        self.name = "WhatsApp Reception"
        self.qualification_threshold = 0.7

    async def run(self, client_id: str, config: Optional[Dict] = None):
        """Process new WhatsApp leads for a client"""
        print(f"📱 {self.name} running for client {client_id}")

        conn = get_db_connection()
        cursor = conn.cursor()

        # Get unprocessed leads
        cursor.execute("""
            SELECT id, phone, name, metadata
            FROM leads
            WHERE
                client_id = %s
                AND source = 'whatsapp'
                AND stage = 'NEW'
                AND qualified = false
            ORDER BY created_at DESC
            LIMIT 10
        """, (client_id,))

        leads = cursor.fetchall()

        processed = 0
        for lead in leads:
            message = lead['metadata'].get('firstMessage', '') if lead['metadata'] else ''
            result = await self.qualify_lead(
                lead['id'],
                message,
                lead['phone'],
                lead['name']
            )
            if result:
                processed += 1

        cursor.close()
        conn.close()

        print(f"✅ {self.name} processed {processed} leads")
        return {"processed": processed}

    async def qualify_lead(
        self,
        lead_id: str,
        message: str,
        phone: str,
        name: Optional[str] = None
    ) -> Dict:
        """
        Qualify a lead based on message content
        Uses simple keyword matching (in production, use LLM)
        """

        # Simple qualification logic (replace with LLM in production)
        score = 0.0
        reasoning_parts = []

        # Keywords indicating interest
        interest_keywords = [
            'orçamento', 'preço', 'custo', 'valor', 'contratar', 'interessado',
            'quero', 'preciso', 'gostaria', 'marketing', 'vendas', 'leads',
            'anúncios', 'campanhas', 'facebook', 'instagram', 'ads'
        ]

        # Keywords indicating questions
        question_keywords = ['como', 'quanto', 'quando', 'onde', 'qual', '?']

        message_lower = message.lower()

        # Check for interest keywords
        interest_count = sum(1 for kw in interest_keywords if kw in message_lower)
        if interest_count > 0:
            score += 0.3
            reasoning_parts.append(f"Shows interest ({interest_count} keywords)")

        # Check for questions
        question_count = sum(1 for kw in question_keywords if kw in message_lower)
        if question_count > 0:
            score += 0.2
            reasoning_parts.append("Asks questions")

        # Check message length (longer = more engaged)
        if len(message) > 50:
            score += 0.2
            reasoning_parts.append("Detailed message")

        # Check for phone/email in message (already engaged)
        if re.search(r'\d{10,11}', message):
            score += 0.1
            reasoning_parts.append("Provided phone")

        if '@' in message:
            score += 0.1
            reasoning_parts.append("Provided email")

        # Check if name is provided
        if name:
            score += 0.1
            reasoning_parts.append("Has name")

        # Cap at 1.0
        score = min(score, 1.0)

        qualified = score >= self.qualification_threshold

        # Determine stage
        if score >= 0.8:
            stage = "QUALIFIED"
        elif score >= 0.5:
            stage = "CONTACTED"
        else:
            stage = "NEW"

        reasoning = "; ".join(reasoning_parts) if reasoning_parts else "Low engagement signals"

        # Update lead in database
        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("""
            UPDATE leads
            SET
                qualified = %s,
                quality_score = %s,
                stage = %s,
                notes = %s,
                updated_at = NOW()
            WHERE id = %s
        """, (
            qualified,
            score * 100,  # Store as 0-100
            stage,
            f"Auto-qualified by WhatsApp Agent: {reasoning}",
            lead_id
        ))

        conn.commit()
        cursor.close()
        conn.close()

        print(f"✅ Lead {lead_id} qualified: {qualified} (score: {score:.2f})")

        return {
            "qualified": qualified,
            "quality_score": score,
            "reasoning": reasoning,
            "suggested_stage": stage
        }
