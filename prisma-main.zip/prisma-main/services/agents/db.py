"""
Database connection utilities
"""

import os
import psycopg2
from psycopg2.extras import RealDictCursor
from typing import Optional

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://prisma:prisma@localhost:5432/prisma_dev")


def get_db_connection():
    """Get a new database connection"""
    return psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor)


def init_db():
    """Initialize database connection and test it"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.close()
        conn.close()
        print("Database connection successful")
    except Exception as e:
        print(f"Database connection failed: {e}")
        raise
