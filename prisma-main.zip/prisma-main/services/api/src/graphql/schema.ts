import gql from 'graphql-tag'

export const typeDefs = gql`
  # ============================================================================
  # SCALARS
  # ============================================================================
  scalar DateTime
  scalar Decimal
  scalar JSON

  # ============================================================================
  # USER & AUTH
  # ============================================================================
  type User {
    id: ID!
    email: String!
    name: String
    role: UserRole!
    client: Client
    createdAt: DateTime!
  }

  enum UserRole {
    ADMIN
    AGENCY
    CLIENT
  }

  type AuthPayload {
    token: String!
    user: User!
  }

  # ============================================================================
  # CLIENT (TENANT)
  # ============================================================================
  type Client {
    id: ID!
    name: String!
    slug: String!
    email: String!
    phone: String
    status: ClientStatus!
    monthlyPlan: Decimal!
    contractStart: DateTime!
    contractEnd: DateTime

    # Aggregations
    campaigns: [Campaign!]!
    campaignCount: Int!
    alerts: [Alert!]!
    activeAlertCount: Int!

    # Analytics
    totalSpend: Decimal!
    totalRevenue: Decimal!
    avgROAS: Decimal!

    createdAt: DateTime!
    updatedAt: DateTime!
  }

  enum ClientStatus {
    ACTIVE
    PAUSED
    CHURNED
    TRIAL
  }

  # ============================================================================
  # CAMPAIGNS & ADS
  # ============================================================================
  type Campaign {
    id: ID!
    fbCampaignId: String!
    name: String!
    objective: String
    status: CampaignStatus!
    dailyBudget: Decimal
    startDate: DateTime
    endDate: DateTime

    # Relations
    client: Client!
    ads: [Ad!]!

    # Aggregated metrics
    totalSpend: Decimal!
    totalRevenue: Decimal!
    totalConversions: Int!
    avgCPC: Decimal!
    avgROAS: Decimal!

    createdAt: DateTime!
    updatedAt: DateTime!
  }

  enum CampaignStatus {
    ACTIVE
    PAUSED
    DELETED
    ARCHIVED
  }

  type Ad {
    id: ID!
    fbAdId: String!
    name: String!
    status: AdStatus!
    campaign: Campaign!
    creative: JSON

    # Metrics
    totalImpressions: Int!
    totalClicks: Int!
    totalSpend: Decimal!
    avgCTR: Decimal!

    createdAt: DateTime!
  }

  enum AdStatus {
    ACTIVE
    PAUSED
    DELETED
    ARCHIVED
  }

  # ============================================================================
  # METRICS
  # ============================================================================
  type MetricRecord {
    id: ID!
    timestamp: DateTime!
    date: DateTime!

    impressions: Int!
    clicks: Int!
    spend: Decimal!
    conversions: Int!
    revenue: Decimal!

    cpc: Decimal!
    ctr: Decimal!
    cpm: Decimal!
    conversionRate: Decimal!
    roas: Decimal!

    source: String!
    campaign: Campaign
    ad: Ad
  }

  type DailyMetrics {
    date: DateTime!
    impressions: Int!
    clicks: Int!
    spend: Decimal!
    conversions: Int!
    revenue: Decimal!
    cpc: Decimal!
    ctr: Decimal!
    roas: Decimal!
  }

  type MetricsSummary {
    totalSpend: Decimal!
    totalRevenue: Decimal!
    totalConversions: Int!
    totalClicks: Int!
    totalImpressions: Int!
    avgCPC: Decimal!
    avgCTR: Decimal!
    avgROAS: Decimal!
    periodStart: DateTime!
    periodEnd: DateTime!
  }

  # ============================================================================
  # ALERTS & AGENTS
  # ============================================================================
  type Alert {
    id: ID!
    type: AlertType!
    severity: AlertSeverity!
    title: String!
    message: String!
    status: AlertStatus!
    metadata: JSON

    client: Client!
    agent: Agent

    resolvedAt: DateTime
    resolvedBy: String
    createdAt: DateTime!
    updatedAt: DateTime!
  }

  enum AlertType {
    HIGH_CPC
    LOW_CTR
    LOW_CONVERSION
    BUDGET_EXCEEDED
    CAMPAIGN_PAUSED
    LEAD_QUALITY
    CUSTOM
  }

  enum AlertSeverity {
    LOW
    MEDIUM
    HIGH
    CRITICAL
  }

  enum AlertStatus {
    PENDING
    ACKNOWLEDGED
    RESOLVED
    IGNORED
  }

  type Agent {
    id: ID!
    name: String!
    type: AgentType!
    description: String
    status: AgentStatus!
    config: JSON
    lastRunAt: DateTime
    runCount: Int!
    createdAt: DateTime!
  }

  enum AgentType {
    WHATSAPP_RECEPTION
    SALES_CLOSER
    CPC_MONITOR
    CTR_MONITOR
    CONVERSION_MONITOR
    COORDINATOR
    CUSTOM
  }

  enum AgentStatus {
    ACTIVE
    PAUSED
    ERROR
  }

  # ============================================================================
  # LEADS
  # ============================================================================
  type Lead {
    id: ID!
    name: String
    email: String
    phone: String
    source: String!
    qualified: Boolean!
    qualityScore: Decimal
    stage: LeadStage!
    notes: String
    metadata: JSON
    createdAt: DateTime!
    updatedAt: DateTime!
  }

  enum LeadStage {
    NEW
    CONTACTED
    QUALIFIED
    PROPOSAL_SENT
    NEGOTIATION
    WON
    LOST
  }

  # ============================================================================
  # CONTENT REQUESTS
  # ============================================================================
  type ContentRequest {
    id: ID!
    client: Client!
    type: ContentType!
    title: String!
    description: String!
    briefing: String
    references: JSON
    format: String
    duration: Int
    specs: JSON
    status: ContentRequestStatus!
    priority: ContentPriority!
    dueDate: DateTime
    deliveredAt: DateTime
    deliveryUrl: String
    revisions: Int!
    maxRevisions: Int!
    assignedTo: String
    notes: String
    createdAt: DateTime!
    updatedAt: DateTime!
  }

  enum ContentType {
    VIDEO_AD
    IMAGE_AD
    CAROUSEL
    STORY
    REEL
    THUMBNAIL
    BANNER
    LANDING_PAGE
    EMAIL_TEMPLATE
    CUSTOM
  }

  enum ContentRequestStatus {
    PENDING
    IN_PROGRESS
    REVIEW
    APPROVED
    REVISION_NEEDED
    DELIVERED
    CANCELLED
  }

  enum ContentPriority {
    LOW
    MEDIUM
    HIGH
    URGENT
  }

  input CreateContentRequestInput {
    type: ContentType!
    title: String!
    description: String!
    briefing: String
    references: JSON
    format: String
    duration: Int
    specs: JSON
    priority: ContentPriority
    dueDate: DateTime
  }

  # ============================================================================
  # INPUTS
  # ============================================================================
  input DateRangeInput {
    start: DateTime!
    end: DateTime!
  }

  # ============================================================================
  # QUERIES
  # ============================================================================
  type Query {
    # Auth
    me: User

    # Clients
    client(id: ID!): Client
    clients: [Client!]!

    # Campaigns
    campaign(id: ID!): Campaign
    campaigns(clientId: ID!): [Campaign!]!

    # Metrics
    dailyMetrics(
      clientId: ID!
      campaignId: ID
      dateRange: DateRangeInput!
    ): [DailyMetrics!]!

    metricsSummary(
      clientId: ID!
      campaignId: ID
      dateRange: DateRangeInput!
    ): MetricsSummary!

    # Alerts
    alerts(
      clientId: ID!
      status: AlertStatus
      severity: AlertSeverity
      limit: Int = 50
    ): [Alert!]!

    # Agents
    agents: [Agent!]!
    agent(id: ID!): Agent

    # Leads
    leads(
      clientId: ID!
      stage: LeadStage
      qualified: Boolean
      limit: Int = 100
    ): [Lead!]!

    # Content Requests
    contentRequests(
      clientId: ID!
      status: ContentRequestStatus
      limit: Int = 50
    ): [ContentRequest!]!

    contentRequest(id: ID!): ContentRequest
  }

  # ============================================================================
  # MUTATIONS
  # ============================================================================
  type Mutation {
    # Auth
    login(email: String!, password: String!): AuthPayload!

    # Alerts
    acknowledgeAlert(id: ID!): Alert!
    resolveAlert(id: ID!, notes: String): Alert!

    # Leads
    updateLeadStage(id: ID!, stage: LeadStage!): Lead!
    addLeadNote(id: ID!, note: String!): Lead!

    # Content Requests
    createContentRequest(input: CreateContentRequestInput!): ContentRequest!
    updateContentRequestStatus(id: ID!, status: ContentRequestStatus!): ContentRequest!
    deliverContent(id: ID!, deliveryUrl: String!): ContentRequest!
    requestRevision(id: ID!, notes: String!): ContentRequest!
  }

  # ============================================================================
  # SUBSCRIPTIONS (Future)
  # ============================================================================
  # type Subscription {
  #   alertCreated(clientId: ID!): Alert!
  #   metricsUpdated(clientId: ID!): MetricRecord!
  # }
`
