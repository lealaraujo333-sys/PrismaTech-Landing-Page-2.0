import { GraphQLScalarType, Kind } from 'graphql'
import { Context, requireAuth, requireClientAccess } from '../context'
import bcrypt from 'bcrypt'
import jwt from 'jsonwebtoken'

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-in-production'

// Custom scalar resolvers
const DateTimeScalar = new GraphQLScalarType({
  name: 'DateTime',
  serialize: (value: any) => value.toISOString(),
  parseValue: (value: any) => new Date(value),
  parseLiteral: (ast) => {
    if (ast.kind === Kind.STRING) {
      return new Date(ast.value)
    }
    return null
  },
})

const DecimalScalar = new GraphQLScalarType({
  name: 'Decimal',
  serialize: (value: any) => parseFloat(value),
  parseValue: (value: any) => value,
  parseLiteral: (ast) => {
    if (ast.kind === Kind.FLOAT || ast.kind === Kind.INT) {
      return parseFloat(ast.value)
    }
    return null
  },
})

const JSONScalar = new GraphQLScalarType({
  name: 'JSON',
  serialize: (value: any) => value,
  parseValue: (value: any) => value,
  parseLiteral: (ast) => {
    if (ast.kind === Kind.STRING) {
      return JSON.parse(ast.value)
    }
    return null
  },
})

export const resolvers = {
  DateTime: DateTimeScalar,
  Decimal: DecimalScalar,
  JSON: JSONScalar,

  Query: {
    // Auth
    me: async (_: any, __: any, context: Context) => {
      const user = requireAuth(context)
      return context.prisma.user.findUnique({ where: { id: user.id } })
    },

    // Clients
    client: async (_: any, { id }: { id: string }, context: Context) => {
      requireClientAccess(context, id)
      return context.prisma.client.findUnique({ where: { id } })
    },

    clients: async (_: any, __: any, context: Context) => {
      const user = requireAuth(context)

      if (user.role === 'ADMIN' || user.role === 'AGENCY') {
        return context.prisma.client.findMany()
      }

      // Client users only see their own client
      if (user.clientId) {
        const client = await context.prisma.client.findUnique({
          where: { id: user.clientId },
        })
        return client ? [client] : []
      }

      return []
    },

    // Campaigns
    campaign: async (_: any, { id }: { id: string }, context: Context) => {
      const campaign = await context.prisma.campaign.findUnique({
        where: { id },
        include: { client: true },
      })

      if (!campaign) throw new Error('Campaign not found')
      requireClientAccess(context, campaign.clientId)

      return campaign
    },

    campaigns: async (_: any, { clientId }: { clientId: string }, context: Context) => {
      requireClientAccess(context, clientId)
      return context.prisma.campaign.findMany({
        where: { clientId },
        orderBy: { createdAt: 'desc' },
      })
    },

    // Metrics
    dailyMetrics: async (
      _: any,
      { clientId, campaignId, dateRange }: any,
      context: Context
    ) => {
      requireClientAccess(context, clientId)

      const records = await context.prisma.metricRecord.groupBy({
        by: ['date'],
        where: {
          clientId,
          campaignId: campaignId || undefined,
          date: {
            gte: dateRange.start,
            lte: dateRange.end,
          },
        },
        _sum: {
          impressions: true,
          clicks: true,
          spend: true,
          conversions: true,
          revenue: true,
        },
        _avg: {
          cpc: true,
          ctr: true,
          roas: true,
        },
        orderBy: { date: 'asc' },
      })

      return records.map((r) => ({
        date: r.date,
        impressions: r._sum.impressions || 0,
        clicks: r._sum.clicks || 0,
        spend: r._sum.spend || 0,
        conversions: r._sum.conversions || 0,
        revenue: r._sum.revenue || 0,
        cpc: r._avg.cpc || 0,
        ctr: r._avg.ctr || 0,
        roas: r._avg.roas || 0,
      }))
    },

    metricsSummary: async (
      _: any,
      { clientId, campaignId, dateRange }: any,
      context: Context
    ) => {
      requireClientAccess(context, clientId)

      const aggregate = await context.prisma.metricRecord.aggregate({
        where: {
          clientId,
          campaignId: campaignId || undefined,
          date: {
            gte: dateRange.start,
            lte: dateRange.end,
          },
        },
        _sum: {
          impressions: true,
          clicks: true,
          spend: true,
          conversions: true,
          revenue: true,
        },
        _avg: {
          cpc: true,
          ctr: true,
          roas: true,
        },
      })

      return {
        totalSpend: aggregate._sum.spend || 0,
        totalRevenue: aggregate._sum.revenue || 0,
        totalConversions: aggregate._sum.conversions || 0,
        totalClicks: aggregate._sum.clicks || 0,
        totalImpressions: aggregate._sum.impressions || 0,
        avgCPC: aggregate._avg.cpc || 0,
        avgCTR: aggregate._avg.ctr || 0,
        avgROAS: aggregate._avg.roas || 0,
        periodStart: dateRange.start,
        periodEnd: dateRange.end,
      }
    },

    // Alerts
    alerts: async (
      _: any,
      { clientId, status, severity, limit }: any,
      context: Context
    ) => {
      requireClientAccess(context, clientId)

      return context.prisma.alert.findMany({
        where: {
          clientId,
          status: status || undefined,
          severity: severity || undefined,
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        include: { agent: true },
      })
    },

    // Agents
    agents: async (_: any, __: any, context: Context) => {
      requireAuth(context)
      return context.prisma.agent.findMany()
    },

    agent: async (_: any, { id }: { id: string }, context: Context) => {
      requireAuth(context)
      return context.prisma.agent.findUnique({ where: { id } })
    },

    // Leads
    leads: async (_: any, { clientId, stage, qualified, limit }: any, context: Context) => {
      requireClientAccess(context, clientId)

      return context.prisma.lead.findMany({
        where: {
          clientId,
          stage: stage || undefined,
          qualified: qualified !== undefined ? qualified : undefined,
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
      })
    },
  },

  Mutation: {
    // Auth
    login: async (_: any, { email, password }: any, context: Context) => {
      const user = await context.prisma.user.findUnique({ where: { email } })

      if (!user || !user.passwordHash) {
        throw new Error('Invalid credentials')
      }

      const valid = await bcrypt.compare(password, user.passwordHash)
      if (!valid) {
        throw new Error('Invalid credentials')
      }

      const token = jwt.sign(
        {
          id: user.id,
          email: user.email,
          role: user.role,
          clientId: user.clientId,
        },
        JWT_SECRET,
        { expiresIn: '7d' }
      )

      return { token, user }
    },

    // Alerts
    acknowledgeAlert: async (_: any, { id }: { id: string }, context: Context) => {
      const user = requireAuth(context)

      const alert = await context.prisma.alert.findUnique({
        where: { id },
      })

      if (!alert) throw new Error('Alert not found')
      requireClientAccess(context, alert.clientId)

      return context.prisma.alert.update({
        where: { id },
        data: { status: 'ACKNOWLEDGED' },
      })
    },

    resolveAlert: async (_: any, { id, notes }: any, context: Context) => {
      const user = requireAuth(context)

      const alert = await context.prisma.alert.findUnique({
        where: { id },
      })

      if (!alert) throw new Error('Alert not found')
      requireClientAccess(context, alert.clientId)

      return context.prisma.alert.update({
        where: { id },
        data: {
          status: 'RESOLVED',
          resolvedAt: new Date(),
          resolvedBy: user.id,
          metadata: {
            ...(typeof alert.metadata === 'object' ? alert.metadata : {}),
            resolutionNotes: notes,
          },
        },
      })
    },

    // Leads
    updateLeadStage: async (_: any, { id, stage }: any, context: Context) => {
      const lead = await context.prisma.lead.findUnique({ where: { id } })
      if (!lead) throw new Error('Lead not found')

      requireClientAccess(context, lead.clientId)

      return context.prisma.lead.update({
        where: { id },
        data: { stage },
      })
    },

    addLeadNote: async (_: any, { id, note }: any, context: Context) => {
      const lead = await context.prisma.lead.findUnique({ where: { id } })
      if (!lead) throw new Error('Lead not found')

      requireClientAccess(context, lead.clientId)

      const currentNotes = lead.notes || ''
      const timestamp = new Date().toISOString()
      const newNotes = `${currentNotes}\n\n[${timestamp}] ${note}`

      return context.prisma.lead.update({
        where: { id },
        data: { notes: newNotes.trim() },
      })
    },
  },

  // Field resolvers
  Client: {
    campaigns: async (parent: any, _: any, context: Context) => {
      return context.prisma.campaign.findMany({
        where: { clientId: parent.id },
      })
    },

    campaignCount: async (parent: any, _: any, context: Context) => {
      return context.prisma.campaign.count({
        where: { clientId: parent.id },
      })
    },

    alerts: async (parent: any, _: any, context: Context) => {
      return context.prisma.alert.findMany({
        where: { clientId: parent.id, status: 'PENDING' },
        orderBy: { createdAt: 'desc' },
        take: 10,
      })
    },

    activeAlertCount: async (parent: any, _: any, context: Context) => {
      return context.prisma.alert.count({
        where: { clientId: parent.id, status: 'PENDING' },
      })
    },

    totalSpend: async (parent: any, _: any, context: Context) => {
      const result = await context.prisma.metricRecord.aggregate({
        where: { clientId: parent.id },
        _sum: { spend: true },
      })
      return result._sum.spend || 0
    },

    totalRevenue: async (parent: any, _: any, context: Context) => {
      const result = await context.prisma.metricRecord.aggregate({
        where: { clientId: parent.id },
        _sum: { revenue: true },
      })
      return result._sum.revenue || 0
    },

    avgROAS: async (parent: any, _: any, context: Context) => {
      const result = await context.prisma.metricRecord.aggregate({
        where: { clientId: parent.id },
        _avg: { roas: true },
      })
      return result._avg.roas || 0
    },
  },

  Campaign: {
    client: async (parent: any, _: any, context: Context) => {
      return context.prisma.client.findUnique({
        where: { id: parent.clientId },
      })
    },

    ads: async (parent: any, _: any, context: Context) => {
      return context.prisma.ad.findMany({
        where: { campaignId: parent.id },
      })
    },

    totalSpend: async (parent: any, _: any, context: Context) => {
      const result = await context.prisma.metricRecord.aggregate({
        where: { campaignId: parent.id },
        _sum: { spend: true },
      })
      return result._sum.spend || 0
    },

    totalRevenue: async (parent: any, _: any, context: Context) => {
      const result = await context.prisma.metricRecord.aggregate({
        where: { campaignId: parent.id },
        _sum: { revenue: true },
      })
      return result._sum.revenue || 0
    },

    totalConversions: async (parent: any, _: any, context: Context) => {
      const result = await context.prisma.metricRecord.aggregate({
        where: { campaignId: parent.id },
        _sum: { conversions: true },
      })
      return result._sum.conversions || 0
    },

    avgCPC: async (parent: any, _: any, context: Context) => {
      const result = await context.prisma.metricRecord.aggregate({
        where: { campaignId: parent.id },
        _avg: { cpc: true },
      })
      return result._avg.cpc || 0
    },

    avgROAS: async (parent: any, _: any, context: Context) => {
      const result = await context.prisma.metricRecord.aggregate({
        where: { campaignId: parent.id },
        _avg: { roas: true },
      })
      return result._avg.roas || 0
    },
  },

  Ad: {
    campaign: async (parent: any, _: any, context: Context) => {
      return context.prisma.campaign.findUnique({
        where: { id: parent.campaignId },
      })
    },

    totalImpressions: async (parent: any, _: any, context: Context) => {
      const result = await context.prisma.metricRecord.aggregate({
        where: { adId: parent.id },
        _sum: { impressions: true },
      })
      return result._sum.impressions || 0
    },

    totalClicks: async (parent: any, _: any, context: Context) => {
      const result = await context.prisma.metricRecord.aggregate({
        where: { adId: parent.id },
        _sum: { clicks: true },
      })
      return result._sum.clicks || 0
    },

    totalSpend: async (parent: any, _: any, context: Context) => {
      const result = await context.prisma.metricRecord.aggregate({
        where: { adId: parent.id },
        _sum: { spend: true },
      })
      return result._sum.spend || 0
    },

    avgCTR: async (parent: any, _: any, context: Context) => {
      const result = await context.prisma.metricRecord.aggregate({
        where: { adId: parent.id },
        _avg: { ctr: true },
      })
      return result._avg.ctr || 0
    },
  },

  Alert: {
    client: async (parent: any, _: any, context: Context) => {
      return context.prisma.client.findUnique({
        where: { id: parent.clientId },
      })
    },

    agent: async (parent: any, _: any, context: Context) => {
      if (!parent.agentId) return null
      return context.prisma.agent.findUnique({
        where: { id: parent.agentId },
      })
    },
  },
}
