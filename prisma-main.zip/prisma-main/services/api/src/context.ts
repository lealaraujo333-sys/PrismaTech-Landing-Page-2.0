import { Request, Response } from 'express'
import { PrismaClient } from '@prisma/client'
import jwt from 'jsonwebtoken'

const prisma = new PrismaClient()

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-in-production'

export interface User {
  id: string
  email: string
  role: string
  clientId?: string
}

export interface Context {
  prisma: typeof prisma
  user?: User
  req: Request
  res: Response
}

export async function createContext({ req, res }: { req: Request; res: Response }): Promise<Context> {
  const token = req.headers.authorization?.replace('Bearer ', '')

  let user: User | undefined

  if (token) {
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as User
      user = decoded
    } catch (error) {
    }
  }

  return {
    prisma,
    user,
    req,
    res,
  }
}

export function requireAuth(context: Context) {
  if (!context.user) {
    throw new Error('Authentication required')
  }
  return context.user
}

export function requireRole(context: Context, roles: string[]) {
  const user = requireAuth(context)
  if (!roles.includes(user.role)) {
    throw new Error('Insufficient permissions')
  }
  return user
}

export function requireClientAccess(context: Context, clientId: string) {
  const user = requireAuth(context)

  if (user.role === 'ADMIN' || user.role === 'AGENCY') {
    return user
  }

  if (user.clientId !== clientId) {
    throw new Error('Access denied to this client')
  }

  return user
}
