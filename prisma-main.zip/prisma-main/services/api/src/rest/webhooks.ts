import { Router } from 'express'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export const webhookRouter = Router()

webhookRouter.post('/facebook', async (req, res) => {
  try {
    const { object, entry } = req.body

    if (object !== 'page') {
      return res.status(400).json({ error: 'Invalid object type' })
    }

    console.log('Facebook webhook received:', JSON.stringify(entry, null, 2))

    res.json({ success: true })
  } catch (error) {
    console.error('Facebook webhook error:', error)
    res.status(500).json({ error: 'Internal server error' })
  }
})

webhookRouter.get('/facebook', (req, res) => {
  const mode = req.query['hub.mode']
  const token = req.query['hub.verify_token']
  const challenge = req.query['hub.challenge']

  const VERIFY_TOKEN = process.env.FB_VERIFY_TOKEN || 'prisma_verify_token'

  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    console.log('✅ Facebook webhook verified')
    res.status(200).send(challenge)
  } else {
    res.status(403).send('Verification failed')
  }
})

webhookRouter.post('/whatsapp', async (req, res) => {
  try {
    const { From, Body, ProfileName } = req.body

    console.log('📱 WhatsApp message received:', {
      from: From,
      name: ProfileName,
      body: Body,
    })

   const clientId = req.query.clientId as string

    if (clientId) {
      // Create or update lead
      await prisma.lead.upsert({
        where: {
          phone: From,
        },
        update: {
          lastContactAt: new Date(),
          metadata: {
            lastMessage: Body,
            lastMessageAt: new Date().toISOString(),
          },
        },
        create: {
          clientId,
          phone: From,
          name: ProfileName,
          source: 'whatsapp',
          stage: 'NEW',
          metadata: {
            firstMessage: Body,
            firstMessageAt: new Date().toISOString(),
          },
        },
      })
    }

    // Respond to Twilio
    res.set('Content-Type', 'text/xml')
    res.send(`
      <?xml version="1.0" encoding="UTF-8"?>
      <Response>
        <Message>Obrigado pela sua mensagem! Nossa equipe irá responder em breve.</Message>
      </Response>
    `)
  } catch (error) {
    console.error('WhatsApp webhook error:', error)
    res.status(500).json({ error: 'Internal server error' })
  }
})

// Agent alerts webhook (internal)
webhookRouter.post('/agent-alerts', async (req, res) => {
  try {
    const { clientId, agentId, type, severity, title, message, metadata } = req.body

    const alert = await prisma.alert.create({
      data: {
        clientId,
        agentId,
        type,
        severity,
        title,
        message,
        metadata,
        status: 'PENDING',
      },
    })

    console.log('🚨 Alert created:', alert.id)

    // TODO: Send notification (email, Slack, WhatsApp)

    res.json({ success: true, alertId: alert.id })
  } catch (error) {
    console.error('Agent alert webhook error:', error)
    res.status(500).json({ error: 'Internal server error' })
  }
})

// Billing webhook (payment gateway)
webhookRouter.post('/billing', async (req, res) => {
  try {
    const { event, clientId, amount, transactionId } = req.body

    console.log('💳 Billing event:', event, 'for client:', clientId)

    // TODO: Implement real payment gateway integration (Stripe, Pagarme, etc.)

    if (event === 'payment.succeeded') {
      // Update billing record
      await prisma.billing.updateMany({
        where: {
          clientId,
          status: 'PENDING',
        },
        data: {
          status: 'PAID',
          paidAt: new Date(),
          transactionId,
        },
      })
    } else if (event === 'payment.failed') {
      // Update billing record and pause client
      await prisma.billing.updateMany({
        where: {
          clientId,
          status: 'PENDING',
        },
        data: {
          status: 'FAILED',
        },
      })

      // Optionally pause client after failed payment
      // await prisma.client.update({
      //   where: { id: clientId },
      //   data: { status: 'PAUSED' }
      // })
    }

    res.json({ success: true })
  } catch (error) {
    console.error('Billing webhook error:', error)
    res.status(500).json({ error: 'Internal server error' })
  }
})

// Health check for webhooks
webhookRouter.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    endpoints: [
      '/facebook',
      '/whatsapp',
      '/agent-alerts',
      '/billing',
    ],
  })
})
