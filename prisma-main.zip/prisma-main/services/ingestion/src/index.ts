import cron from 'node-cron'
import { PrismaClient } from '@prisma/client'
import { ingestFacebookAds } from './facebook-ingestion'
import dotenv from 'dotenv'
import path from 'path'

dotenv.config({ path: path.resolve(__dirname, '../../../.env') })

const prisma = new PrismaClient()

console.log('🔄 Starting Prisma Ingestion Service...')

// Run ingestion every hour
cron.schedule('0 * * * *', async () => {
  console.log('⏰ Running scheduled ingestion...')
  await runIngestion()
})

// Also run on startup
runIngestion()

async function runIngestion() {
  try {
    console.log('📥 Starting Facebook Ads ingestion...')

    // Get all active clients
    const clients = await prisma.client.findMany({
      where: {
        status: 'ACTIVE',
        fbAccessToken: { not: null },
      },
    })

    console.log(`Found ${clients.length} active clients`)

    for (const client of clients) {
      try {
        await ingestFacebookAds(client)
        console.log(`✅ Ingested data for client: ${client.name}`)
      } catch (error) {
        console.error(`❌ Failed to ingest for client ${client.name}:`, error)
      }
    }

    console.log('✅ Ingestion completed successfully')
  } catch (error) {
    console.error('❌ Ingestion failed:', error)
  }
}

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('Shutting down ingestion service...')
  await prisma.$disconnect()
  process.exit(0)
})
