import { PrismaClient } from '@prisma/client'

// Export Prisma Client instance
export const prisma = new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
})

// Export all types
export * from '@prisma/client'

// Graceful shutdown
if (process.env.NODE_ENV !== 'test') {
  process.on('beforeExit', async () => {
    await prisma.$disconnect()
  })
}

// Helper function to enable TimescaleDB hypertable for metrics
export async function enableTimescaleDB() {
  try {
    // Create TimescaleDB extension if not exists
    await prisma.$executeRaw`CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;`

    // Convert metric_records to hypertable (partitioned by timestamp)
    await prisma.$executeRaw`
      SELECT create_hypertable(
        'metric_records',
        'timestamp',
        if_not_exists => TRUE,
        chunk_time_interval => INTERVAL '1 day'
      );
    `

    // Create continuous aggregate for daily metrics
    await prisma.$executeRaw`
      CREATE MATERIALIZED VIEW IF NOT EXISTS metric_records_daily
      WITH (timescaledb.continuous) AS
      SELECT
        client_id,
        campaign_id,
        time_bucket('1 day', timestamp) AS day,
        SUM(impressions) as total_impressions,
        SUM(clicks) as total_clicks,
        SUM(spend) as total_spend,
        SUM(conversions) as total_conversions,
        SUM(revenue) as total_revenue,
        AVG(cpc) as avg_cpc,
        AVG(ctr) as avg_ctr,
        AVG(roas) as avg_roas
      FROM metric_records
      GROUP BY client_id, campaign_id, day
      WITH NO DATA;
    `

    // Add refresh policy (refresh every hour)
    await prisma.$executeRaw`
      SELECT add_continuous_aggregate_policy('metric_records_daily',
        start_offset => INTERVAL '3 days',
        end_offset => INTERVAL '1 hour',
        schedule_interval => INTERVAL '1 hour',
        if_not_exists => TRUE
      );
    `

    console.log('✅ TimescaleDB hypertable configured successfully')
  } catch (error) {
    console.error('❌ TimescaleDB setup error:', error)
    // Don't throw - allow app to continue with regular PostgreSQL
  }
}

// Utility functions for multi-tenant queries
export function clientScope(clientId: string) {
  return {
    where: { clientId }
  }
}

export default prisma
