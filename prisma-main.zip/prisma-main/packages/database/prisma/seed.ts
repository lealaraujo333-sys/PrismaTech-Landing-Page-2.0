import { PrismaClient } from '@prisma/client'
import { Decimal } from '@prisma/client/runtime/library'
import * as dotenv from 'dotenv'
import * as path from 'path'
import bcrypt from 'bcrypt'

// Load environment variables from root .env
dotenv.config({ path: path.resolve(__dirname, '../../../.env') })

const prisma = new PrismaClient()

// Hash password for demo users
async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10)
}

// Helper to generate dates
function daysAgo(days: number): Date {
  const date = new Date()
  date.setDate(date.getDate() - days)
  return date
}

// Helper to generate realistic metrics with variance
function generateMetrics(baseSpend: number, day: number) {
  // Add variance and trend (improving over time)
  const trendMultiplier = 1 + (day / 90) * 0.3 // 30% improvement over 90 days
  const variance = 0.85 + Math.random() * 0.3 // ±15% daily variance

  const spend = baseSpend * variance
  const impressions = Math.floor((spend / 0.015) * (0.8 + Math.random() * 0.4)) // $0.01-0.02 CPM
  const clicks = Math.floor(impressions * (0.018 + Math.random() * 0.015) * trendMultiplier) // 1.8-3.3% CTR
  const ctr = (clicks / impressions) * 100
  const cpc = spend / clicks
  const cpm = (spend / impressions) * 1000

  // Conversions improve with better targeting over time
  const conversions = Math.floor(clicks * (0.025 + Math.random() * 0.015) * trendMultiplier) // 2.5-4% conversion
  const conversionRate = (conversions / clicks) * 100

  // Revenue based on average ticket
  const avgTicket = 800 + Math.random() * 400 // R$ 800-1200
  const revenue = conversions * avgTicket
  const roas = revenue / spend

  return {
    impressions,
    clicks,
    spend: new Decimal(spend.toFixed(2)),
    conversions,
    revenue: new Decimal(revenue.toFixed(2)),
    cpc: new Decimal(cpc.toFixed(2)),
    ctr: new Decimal(ctr.toFixed(2)),
    cpm: new Decimal(cpm.toFixed(2)),
    conversionRate: new Decimal(conversionRate.toFixed(2)),
    roas: new Decimal(roas.toFixed(2)),
  }
}

async function main() {
  console.log('🌱 Starting database seed...')

  // Clean existing data
  console.log('🧹 Cleaning existing data...')
  await prisma.metricRecord.deleteMany()
  await prisma.alert.deleteMany()
  await prisma.lead.deleteMany()
  await prisma.billing.deleteMany()
  await prisma.ad.deleteMany()
  await prisma.campaign.deleteMany()
  await prisma.user.deleteMany()
  await prisma.client.deleteMany()
  await prisma.agent.deleteMany()

  // ============================================================================
  // AGENTS
  // ============================================================================
  console.log('🤖 Creating AI Agents...')

  const agents = await Promise.all([
    prisma.agent.create({
      data: {
        name: 'Agente WhatsApp - Recepção',
        type: 'WHATSAPP_RECEPTION',
        description: 'Recepciona, qualifica e direciona leads do WhatsApp',
        status: 'ACTIVE',
        lastRunAt: daysAgo(0),
        runCount: 1247,
        config: {
          qualificationThreshold: 0.7,
          responseTemplates: true,
        },
      },
    }),
    prisma.agent.create({
      data: {
        name: 'Agente Closer - Vendas',
        type: 'SALES_CLOSER',
        description: 'Consultor que personaliza propostas e fecha negócios',
        status: 'ACTIVE',
        lastRunAt: daysAgo(0),
        runCount: 234,
        config: {
          proposalTemplates: 3,
          followUpInterval: 48,
        },
      },
    }),
    prisma.agent.create({
      data: {
        name: 'Monitor CPC',
        type: 'CPC_MONITOR',
        description: 'Detecta picos de CPC e gera alertas automáticos',
        status: 'ACTIVE',
        lastRunAt: daysAgo(0),
        runCount: 8640,
        config: {
          threshold: 1.6,
          window: '24h',
        },
      },
    }),
    prisma.agent.create({
      data: {
        name: 'Monitor CTR',
        type: 'CTR_MONITOR',
        description: 'Identifica quedas de CTR e sugere otimizações',
        status: 'ACTIVE',
        lastRunAt: daysAgo(0),
        runCount: 8640,
        config: {
          minCTR: 1.5,
          dropThreshold: 0.2,
        },
      },
    }),
    prisma.agent.create({
      data: {
        name: 'Agente Coordenador',
        type: 'COORDINATOR',
        description: 'Orquestra todos os agentes e faz load balancing',
        status: 'ACTIVE',
        lastRunAt: daysAgo(0),
        runCount: 3421,
        config: {
          loadBalancing: true,
          priority: 'round-robin',
        },
      },
    }),
    prisma.agent.create({
      data: {
        name: 'Monitor de Conversão',
        type: 'CONVERSION_MONITOR',
        description: 'Analisa taxa de conversão e identifica gargalos',
        status: 'PAUSED',
        lastRunAt: daysAgo(2),
        runCount: 4320,
        config: {
          minConversionRate: 2.0,
        },
      },
    }),
  ])

  // ============================================================================
  // CLIENTS (DEMO ACCOUNTS)
  // ============================================================================
  console.log('👥 Creating demo clients...')

  const clients = await Promise.all([
    prisma.client.create({
      data: {
        name: 'Empresa Demo Principal',
        slug: 'empresa-demo',
        email: 'contato@empresademo.com.br',
        phone: '+55 11 98765-4321',
        status: 'ACTIVE',
        monthlyPlan: new Decimal('3800.00'),
        contractStart: daysAgo(180),
        fbAdAccountId: 'act_123456789',
        fbBusinessManagerId: 'bm_987654321',
      },
    }),
    prisma.client.create({
      data: {
        name: 'Boutique Fashion Store',
        slug: 'boutique-fashion',
        email: 'vendas@boutiquefashion.com.br',
        phone: '+55 11 91234-5678',
        status: 'ACTIVE',
        monthlyPlan: new Decimal('3800.00'),
        contractStart: daysAgo(90),
        fbAdAccountId: 'act_234567890',
        fbBusinessManagerId: 'bm_876543210',
      },
    }),
    prisma.client.create({
      data: {
        name: 'Tech Startup Brasil',
        slug: 'tech-startup',
        email: 'marketing@techstartup.io',
        phone: '+55 48 99876-5432',
        status: 'TRIAL',
        monthlyPlan: new Decimal('3800.00'),
        contractStart: daysAgo(15),
        fbAdAccountId: 'act_345678901',
        fbBusinessManagerId: 'bm_765432109',
      },
    }),
  ])

  // ============================================================================
  // USERS
  // ============================================================================
  console.log('👤 Creating users...')

  // Hash password: "demo123" for all demo users
  const demoPasswordHash = await hashPassword('demo123')

  await Promise.all([
    // Admin user
    prisma.user.create({
      data: {
        email: 'admin@prisma.agency',
        name: 'Admin Prisma',
        role: 'ADMIN',
        passwordHash: demoPasswordHash,
      },
    }),
    // Client users
    prisma.user.create({
      data: {
        email: 'contato@empresademo.com.br',
        name: 'João Silva',
        role: 'CLIENT',
        clientId: clients[0].id,
        passwordHash: demoPasswordHash,
      },
    }),
    prisma.user.create({
      data: {
        email: 'vendas@boutiquefashion.com.br',
        name: 'Maria Santos',
        role: 'CLIENT',
        clientId: clients[1].id,
        passwordHash: demoPasswordHash,
      },
    }),
  ])

  // ============================================================================
  // CAMPAIGNS & ADS
  // ============================================================================
  console.log('📢 Creating campaigns and ads...')

  const campaignsData = [
    {
      client: clients[0],
      name: 'Black Friday 2024',
      objective: 'CONVERSIONS',
      dailyBudget: 150,
      ads: ['Anúncio Carrossel 1', 'Anúncio Video 1', 'Anúncio Imagem 1'],
    },
    {
      client: clients[0],
      name: 'Retargeting Q4',
      objective: 'CONVERSIONS',
      dailyBudget: 80,
      ads: ['Retargeting Carrinho', 'Retargeting Visualizações'],
    },
    {
      client: clients[1],
      name: 'Lançamento Coleção Verão',
      objective: 'CONVERSIONS',
      dailyBudget: 120,
      ads: ['Carrossel Produtos', 'Video Stories'],
    },
    {
      client: clients[1],
      name: 'Awareness Marca',
      objective: 'REACH',
      dailyBudget: 60,
      ads: ['Video Brand', 'Imagem Lifestyle'],
    },
    {
      client: clients[2],
      name: 'Lead Generation Tech',
      objective: 'LEAD_GENERATION',
      dailyBudget: 100,
      ads: ['Form Lead Ads', 'Video Explicativo'],
    },
  ]

  for (const campaignData of campaignsData) {
    const campaign = await prisma.campaign.create({
      data: {
        clientId: campaignData.client.id,
        fbCampaignId: `fb_camp_${Math.random().toString(36).substring(7)}`,
        fbAdAccountId: campaignData.client.fbAdAccountId!,
        name: campaignData.name,
        objective: campaignData.objective,
        status: 'ACTIVE',
        dailyBudget: new Decimal(campaignData.dailyBudget),
        startDate: daysAgo(90),
        createdAt: daysAgo(90),
      },
    })

    // Create ads for this campaign
    for (let i = 0; i < campaignData.ads.length; i++) {
      await prisma.ad.create({
        data: {
          campaignId: campaign.id,
          fbAdId: `fb_ad_${Math.random().toString(36).substring(7)}`,
          fbAdSetId: `fb_adset_${Math.random().toString(36).substring(7)}`,
          name: campaignData.ads[i],
          status: 'ACTIVE',
          creative: {
            type: i % 3 === 0 ? 'carousel' : i % 3 === 1 ? 'video' : 'image',
            headline: 'Headline do anúncio',
            description: 'Descrição do anúncio',
          },
        },
      })
    }

    // ============================================================================
    // METRICS (90 days of daily data)
    // ============================================================================
    console.log(`📊 Generating metrics for ${campaign.name}...`)

    for (let day = 90; day >= 0; day--) {
      const date = daysAgo(day)
      const metrics = generateMetrics(campaignData.dailyBudget, 90 - day)

      await prisma.metricRecord.create({
        data: {
          clientId: campaignData.client.id,
          campaignId: campaign.id,
          timestamp: date,
          date: date,
          ...metrics,
          source: 'facebook',
        },
      })
    }
  }

  // ============================================================================
  // ALERTS
  // ============================================================================
  console.log('🚨 Creating sample alerts...')

  const firstCampaign = await prisma.campaign.findFirst()

  await Promise.all([
    prisma.alert.create({
      data: {
        clientId: clients[0].id,
        agentId: agents[2].id, // CPC Monitor
        type: 'HIGH_CPC',
        severity: 'HIGH',
        title: 'CPC aumentou 1.8x nas últimas 24h',
        message: 'O custo por clique da campanha "Black Friday 2024" aumentou de R$ 0.68 para R$ 1.22. Recomendamos revisar os lances e a segmentação.',
        status: 'PENDING',
        metadata: {
          previousCPC: 0.68,
          currentCPC: 1.22,
          threshold: 1.6,
          campaignName: 'Black Friday 2024',
        },
        createdAt: daysAgo(0),
      },
    }),
    prisma.alert.create({
      data: {
        clientId: clients[0].id,
        agentId: agents[3].id, // CTR Monitor
        type: 'LOW_CTR',
        severity: 'MEDIUM',
        title: 'CTR abaixo da meta em 2 anúncios',
        message: 'O CTR caiu para 1.2% em "Anúncio Imagem 1" e "Retargeting Visualizações". Meta: 2.0%.',
        status: 'ACKNOWLEDGED',
        metadata: {
          affectedAds: 2,
          currentCTR: 1.2,
          targetCTR: 2.0,
        },
        createdAt: daysAgo(1),
      },
    }),
    prisma.alert.create({
      data: {
        clientId: clients[1].id,
        agentId: agents[0].id, // WhatsApp Agent
        type: 'LEAD_QUALITY',
        severity: 'LOW',
        title: 'Novo lead qualificado via WhatsApp',
        message: 'Lead "Ana Costa" qualificado com score 87/100. Interesse em plano completo.',
        status: 'RESOLVED',
        resolvedAt: daysAgo(0),
        metadata: {
          leadName: 'Ana Costa',
          qualityScore: 87,
          source: 'whatsapp',
        },
        createdAt: daysAgo(2),
      },
    }),
  ])

  // ============================================================================
  // BILLINGS
  // ============================================================================
  console.log('💰 Creating billing records...')

  for (const client of clients) {
    // Last 3 months of billing
    for (let month = 0; month < 3; month++) {
      const periodEnd = daysAgo(month * 30)
      const periodStart = daysAgo((month + 1) * 30)

      await prisma.billing.create({
        data: {
          clientId: client.id,
          periodStart,
          periodEnd,
          amount: client.monthlyPlan,
          currency: 'BRL',
          status: month === 0 ? 'PENDING' : 'PAID',
          paidAt: month === 0 ? null : periodEnd,
          paymentMethod: month === 0 ? null : 'credit_card',
          transactionId: month === 0 ? null : `txn_${Math.random().toString(36).substring(7)}`,
        },
      })
    }
  }

  // ============================================================================
  // SUMMARY
  // ============================================================================
  console.log('\n✅ Seed completed successfully!\n')
  console.log('📊 Summary:')
  console.log(`   - ${agents.length} AI Agents`)
  console.log(`   - ${clients.length} Demo Clients`)
  console.log(`   - ${campaignsData.length} Campaigns`)
  console.log(`   - ${campaignsData.reduce((sum, c) => sum + c.ads.length, 0)} Ads`)
  console.log(`   - ~${campaignsData.length * 91} Metric Records (90 days)`)
  console.log(`   - 3 Sample Alerts`)
  console.log(`   - ${clients.length * 3} Billing Records\n`)

  console.log('🎯 Demo Login Credentials:')
  console.log('   Admin:  admin@prisma.agency')
  console.log('   Client: contato@empresademo.com.br')
  console.log('   Password: demo123\n')

  console.log('🚀 Your platform is ready to demo!')
  console.log('   Dashboard: http://localhost:3001')
  console.log('   GraphQL:   http://localhost:4000/graphql\n')
}

main()
  .catch((e) => {
    console.error('❌ Seed error:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
