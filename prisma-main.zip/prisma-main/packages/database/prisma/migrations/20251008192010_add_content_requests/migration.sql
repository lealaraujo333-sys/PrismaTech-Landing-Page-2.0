-- CreateEnum
CREATE TYPE "ContentType" AS ENUM ('VIDEO_AD', 'IMAGE_AD', 'CAROUSEL', 'STORY', 'REEL', 'THUMBNAIL', 'BANNER', 'LANDING_PAGE', 'EMAIL_TEMPLATE', 'CUSTOM');

-- CreateEnum
CREATE TYPE "ContentRequestStatus" AS ENUM ('PENDING', 'IN_PROGRESS', 'REVIEW', 'APPROVED', 'REVISION_NEEDED', 'DELIVERED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "ContentPriority" AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'URGENT');

-- CreateTable
CREATE TABLE "content_requests" (
    "id" TEXT NOT NULL,
    "clientId" TEXT NOT NULL,
    "type" "ContentType" NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "briefing" TEXT,
    "references" JSONB,
    "format" TEXT,
    "duration" INTEGER,
    "specs" JSONB,
    "status" "ContentRequestStatus" NOT NULL DEFAULT 'PENDING',
    "priority" "ContentPriority" NOT NULL DEFAULT 'MEDIUM',
    "dueDate" TIMESTAMP(3),
    "deliveredAt" TIMESTAMP(3),
    "deliveryUrl" TEXT,
    "revisions" INTEGER NOT NULL DEFAULT 0,
    "maxRevisions" INTEGER NOT NULL DEFAULT 2,
    "assignedTo" TEXT,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "content_requests_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "content_requests_clientId_status_idx" ON "content_requests"("clientId", "status");

-- CreateIndex
CREATE INDEX "content_requests_status_priority_idx" ON "content_requests"("status", "priority");

-- CreateIndex
CREATE INDEX "content_requests_dueDate_idx" ON "content_requests"("dueDate");

-- AddForeignKey
ALTER TABLE "content_requests" ADD CONSTRAINT "content_requests_clientId_fkey" FOREIGN KEY ("clientId") REFERENCES "clients"("id") ON DELETE CASCADE ON UPDATE CASCADE;
