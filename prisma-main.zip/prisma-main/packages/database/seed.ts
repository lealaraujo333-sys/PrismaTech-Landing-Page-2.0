import { PrismaClient, ClientStatus, CampaignStatus, AgentType, AgentStatus } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Create demo client
  const client = await prisma.client.upsert({
    where: { slug: 'acme-corp' },
    update: {},
    create: {
      name: 'Acme Corporation',
      slug: 'acme-corp',
      email: 'contact@acmecorp.com',
      phone: '+55 11 99999-9999',
      status: ClientStatus.ACTIVE,
      monthlyPlan: 3800.00,
      billingDay: 1,
      fbAccessToken: 'mock_fb_token_demo',
      fbAdAccountId: 'act_123456789',
    }
  })

  console.log('✅ Created client:', client.name)

  // Create admin user
  const adminUser = await prisma.user.upsert({
    where: { email: 'admin@prisma.agency' },
    update: {},
    create: {
      email: 'admin@prisma.agency',
      name: 'Prisma Admin',
      role: 'ADMIN',
      passwordHash: 'mock_hash', // TODO: Use bcrypt in production
    }
  })

  // Create client user
  const clientUser = await prisma.user.upsert({
    where: { email: 'john@acmecorp.com' },
    update: {},
    create: {
      email: 'john@acmecorp.com',
      name: 'John Doe',
      role: 'CLIENT',
      clientId: client.id,
      passwordHash: 'mock_hash',
    }
  })

  console.log('✅ Created users')

  // Create campaigns
  const campaign1 = await prisma.campaign.upsert({
    where: { fbCampaignId: 'fb_campaign_001' },
    update: {},
    create: {
      clientId: client.id,
      fbCampaignId: 'fb_campaign_001',
      fbAdAccountId: 'act_123456789',
      name: 'Black Friday 2024 - Product Launch',
      objective: 'CONVERSIONS',
      status: CampaignStatus.ACTIVE,
      dailyBudget: 500.00,
      startDate: new Date('2024-01-01'),
    }
  })

  const campaign2 = await prisma.campaign.upsert({
    where: { fbCampaignId: 'fb_campaign_002' },
    update: {},
    create: {
      clientId: client.id,
      fbCampaignId: 'fb_campaign_002',
      fbAdAccountId: 'act_123456789',
      name: 'Q1 Lead Generation',
      objective: 'LEAD_GENERATION',
      status: CampaignStatus.ACTIVE,
      dailyBudget: 300.00,
      startDate: new Date('2024-01-15'),
    }
  })

  console.log('✅ Created campaigns')

  // Create ads
  const ad1 = await prisma.ad.upsert({
    where: { fbAdId: 'fb_ad_001' },
    update: {},
    create: {
      campaignId: campaign1.id,
      fbAdId: 'fb_ad_001',
      fbAdSetId: 'fb_adset_001',
      name: 'Video Ad - Product Demo',
      status: 'ACTIVE',
      creative: {
        type: 'video',
        url: 'https://example.com/video.mp4',
      }
    }
  })

  const ad2 = await prisma.ad.upsert({
    where: { fbAdId: 'fb_ad_002' },
    update: {},
    create: {
      campaignId: campaign1.id,
      fbAdId: 'fb_ad_002',
      fbAdSetId: 'fb_adset_001',
      name: 'Carousel Ad - Features',
      status: 'ACTIVE',
      creative: {
        type: 'carousel',
        images: ['img1.jpg', 'img2.jpg', 'img3.jpg']
      }
    }
  })

  console.log('✅ Created ads')

  // Create AI Agents
  const agents = [
    {
      name: 'WhatsApp Reception',
      type: AgentType.WHATSAPP_RECEPTION,
      description: 'First-line contact for WhatsApp leads. Qualifies and filters incoming messages.',
      status: AgentStatus.ACTIVE,
      config: {
        qualificationThreshold: 0.7,
        autoRespond: true,
        businessHours: { start: 9, end: 18 }
      }
    },
    {
      name: 'Sales Closer',
      type: AgentType.SALES_CLOSER,
      description: 'Handles qualified leads, sends proposals, and schedules meetings.',
      status: AgentStatus.ACTIVE,
      config: {
        followUpDelay: 24, // hours
        maxFollowUps: 3
      }
    },
    {
      name: 'CPC Monitor',
      type: AgentType.CPC_MONITOR,
      description: 'Monitors Cost Per Click anomalies using statistical analysis.',
      status: AgentStatus.ACTIVE,
      config: {
        threshold: 1.6, // 1.6x baseline
        lookbackDays: 7,
        checkInterval: 3600 // seconds
      }
    },
    {
      name: 'CTR Monitor',
      type: AgentType.CTR_MONITOR,
      description: 'Detects Click-Through Rate drops.',
      status: AgentStatus.ACTIVE,
      config: {
        thresholdDrop: 0.20, // 20% drop
        lookbackDays: 7
      }
    },
    {
      name: 'Agent Coordinator',
      type: AgentType.COORDINATOR,
      description: 'Routes tasks between agents and manages workload.',
      status: AgentStatus.ACTIVE,
      config: {
        loadBalancing: true,
        priorityRules: ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']
      }
    }
  ]

  for (const agentData of agents) {
    await prisma.agent.upsert({
      where: {
        name: agentData.name
      },
      update: {},
      create: agentData
    })
  }

  console.log('✅ Created AI agents')

  // Generate 30 days of mock metrics
  const now = new Date()
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)

  console.log('📊 Generating 30 days of metrics...')

  for (let i = 0; i < 30; i++) {
    const date = new Date(thirtyDaysAgo.getTime() + i * 24 * 60 * 60 * 1000)

    // Base metrics with some randomization
    const impressions = Math.floor(5000 + Math.random() * 3000)
    const clicks = Math.floor(impressions * (0.015 + Math.random() * 0.02)) // 1.5-3.5% CTR
    const spend = 450 + Math.random() * 150 // BRL 450-600/day
    const conversions = Math.floor(clicks * (0.05 + Math.random() * 0.10)) // 5-15% conversion
    const revenue = conversions * (150 + Math.random() * 100) // BRL 150-250 per conversion

    const ctr = (clicks / impressions) * 100
    const cpc = spend / clicks
    const cpm = (spend / impressions) * 1000
    const conversionRate = (conversions / clicks) * 100
    const roas = revenue / spend

    await prisma.metricRecord.create({
      data: {
        clientId: client.id,
        campaignId: campaign1.id,
        adId: ad1.id,
        timestamp: date,
        date: date,
        impressions,
        clicks,
        spend,
        conversions,
        revenue,
        cpc,
        ctr,
        cpm,
        conversionRate,
        roas,
        source: 'facebook'
      }
    })
  }

  console.log('✅ Generated 30 days of metrics')

  // Create sample alert
  const cpcAgent = await prisma.agent.findFirst({
    where: { type: AgentType.CPC_MONITOR }
  })

  if (cpcAgent) {
    await prisma.alert.create({
      data: {
        clientId: client.id,
        agentId: cpcAgent.id,
        type: 'HIGH_CPC',
        severity: 'HIGH',
        title: 'CPC Alert: Unusual spike detected',
        message: 'Campaign "Black Friday 2024" has a CPC of BRL 12.50, which is 2.1x above the baseline of BRL 5.95. Consider reviewing targeting or ad creative.',
        status: 'PENDING',
        metadata: {
          campaignId: campaign1.id,
          currentCpc: 12.50,
          baselineCpc: 5.95,
          zScore: 2.8
        }
      }
    })
  }

  console.log('✅ Created sample alert')

  // Create sample lead
  await prisma.lead.create({
    data: {
      clientId: client.id,
      name: 'Maria Silva',
      email: 'maria@example.com',
      phone: '+55 11 98888-7777',
      source: 'whatsapp',
      qualified: true,
      qualityScore: 85.5,
      stage: 'QUALIFIED',
      notes: 'Interested in the premium plan. Budget: BRL 5000/month',
      metadata: {
        campaignSource: campaign1.id,
        firstContactDate: new Date().toISOString()
      }
    }
  })

  console.log('✅ Created sample lead')

  console.log('🎉 Database seeding completed!')
}

main()
  .catch((e) => {
    console.error('❌ Seeding error:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
